# F12测试覆盖映射草稿

不是最终验收，新增与复用需由完整回归证明。

| 场景组 | 新增入口 | 复用入口 |
| --- | --- | --- |
| T01 | tests/unit/test_f12_config.py | tests/unit/test_f3_config.py |
| T02 | tests/unit/test_f12_config.py | tests/unit/test_f11_config.py |
| T03 | tests/unit/test_f12_config.py | tests/unit/test_f3o1_counters.py |
| T04 | tests/unit/test_f12_config.py<br>tests/unit/test_f12_routing.py::test_group_budget_rejection_has_zero_side_effects | tests/unit/test_bug002_registry.py |
| T05 | tests/unit/test_f12_routing.py::test_only_group_names_are_public<br>tests/unit/test_f12_routing.py::test_group_defaults_do_not_follow_endpoint_order<br>tests/unit/test_f12_routing.py::test_group_budget_rejection_has_zero_side_effects<br>tests/integration/test_f12_stream_plan.py::test_public_rejection_has_no_attempt_bill_or_input_snapshot | tests/unit/test_f3_contracts.py |
| T06 | tests/unit/test_f12_routing.py::test_order_not_message_semantics_selects_endpoint<br>tests/unit/test_f12_routing.py::test_concurrent_groups_do_not_mutate_each_others_order_or_trace |  |
| T07 | tests/unit/test_f12_routing.py::test_disabled_primary_calls_only_backup<br>tests/unit/test_f12_routing.py::test_all_rejected_uses_stage_error |  |
| T08 | tests/unit/test_f12_routing.py::test_skipped_candidate_never_enters_plan | tests/unit/test_f5_contracts.py<br>tests/integration/test_f4_gateway.py |
| T09 | tests/unit/test_f12_routing.py::test_skipped_candidate_never_enters_plan<br>tests/unit/test_f12_routing.py::test_initial_budget_does_not_hide_authorized_context_overflow | tests/unit/test_f7_budget_and_repair.py |
| T10 | tests/unit/test_f12_routing.py::test_schema_prompt_and_counter_are_endpoint_specific<br>tests/unit/test_f12_routing.py::test_large_schema_only_excludes_chat_rendering_not_native_schema<br>tests/unit/test_f12_routing.py::test_all_rendered_prompts_too_long_fail_before_counting<br>tests/integration/test_f12_trace_billing.py::test_real_adapter_wire_uses_selected_endpoint_contract_and_tariff | tests/unit/test_f4_json_codec.py<br>tests/unit/test_f7_ordinary_edges.py |
| T11 | tests/unit/test_f12_routing.py::test_endpoint_context_boundary_uses_its_own_counter<br>tests/unit/test_f12_routing.py::test_initial_budget_does_not_hide_authorized_context_overflow | tests/unit/test_f3_token_budget.py<br>tests/unit/test_f4_budget.py |
| T12 | tests/unit/test_f12_routing.py::test_all_rejected_uses_stage_error | tests/unit/test_f12_config.py |
| T13 | tests/unit/test_f12_recovery.py::test_recovery_calls_two_primary_then_actual_backup_without_replacing_route<br>tests/unit/test_f12_recovery.py::test_permanent_failure_cannot_escape_to_other_endpoint<br>tests/unit/test_f12_recovery.py::test_shared_endpoint_requests_keep_recovery_counts_isolated | tests/unit/test_f7_recovery.py |
| T14 | tests/unit/test_f12_recovery.py::test_attempt_timeouts_respect_endpoint_cap_and_request_remaining_budget | tests/unit/test_f7_ordinary_edges.py<br>tests/integration/test_f7_deadline.py<br>tests/integration/test_f11_lifecycle.py |
| T15 | tests/unit/test_f12_recovery.py::test_length_grows_only_to_group_authorization_on_same_endpoint<br>tests/unit/test_f12_recovery.py::test_invalid_json_repairs_once_without_switching_endpoint | tests/unit/test_f7_streaming.py<br>tests/integration/test_f7_streaming_integration.py<br>tests/integration/test_f7_protocol.py |
| T16 | tests/integration/test_f12_stream_plan.py::test_pending_route_is_persisted_without_attempt_or_charge | tests/integration/test_f11_public_acceptance.py |
| T17 |  | tests/integration/test_f5o2_http.py<br>tests/integration/test_f5o2_recovery_claim.py<br>tests/integration/test_f11_lifecycle.py |
| T18 | tests/integration/test_f12_stream_plan.py::test_application_restart_preserves_equivalent_pending_plan<br>tests/smoke/test_f12_restart.py::test_pending_route_across_real_process_restart |  |
| T19 | tests/integration/test_f12_stream_plan.py::test_related_configuration_change_fails_without_call<br>tests/smoke/test_f12_restart.py::test_pending_route_across_real_process_restart | tests/integration/test_f5o2_replay.py |
| T20 | tests/integration/test_f12_stream_plan.py::test_pre_versioned_pending_is_rejected_but_event_history_remains_readable<br>tests/integration/test_f12_trace_billing.py::test_historical_trace_does_not_invent_routing_for_pre_f12_metadata | tests/integration/test_f8_trace_query.py |
| T21 | tests/integration/test_f12_stream_plan.py::test_resume_reads_committed_plan_without_new_generation_or_billing | tests/integration/test_f6_races.py<br>tests/integration/test_f6_faults.py<br>tests/integration/test_f11_lifecycle.py<br>tests/live/test_f10_acceptance.py |
| T22 | tests/integration/test_f12_trace_billing.py::test_fallback_bills_each_actual_tariff_and_keeps_unknown_usage_pending<br>tests/integration/test_f12_trace_billing.py::test_real_adapter_wire_uses_selected_endpoint_contract_and_tariff | tests/integration/test_f9_paid_flow.py<br>tests/integration/test_f9_final_usage.py |
| T23 |  | tests/integration/test_f5o2_faults.py<br>tests/integration/test_f5o2_recovery_claim.py<br>tests/integration/test_f9_stream_budget.py<br>tests/smoke/test_f10_fault_chain.py |
| T24 | tests/integration/test_f12_trace_billing.py::test_trace_read_is_side_effect_free_and_never_projects_body_or_connection_secret<br>tests/integration/test_f12_trace_billing.py::test_historical_trace_does_not_invent_routing_for_pre_f12_metadata<br>tests/unit/test_f12_routing.py::test_related_configuration_hash_ignores_mapping_order_and_unrelated_group | tests/integration/test_f8_trace_query.py<br>tests/integration/test_f9_identity.py |
| T25 | tests/unit/test_f12_recovery.py::test_probe_calls_first_enabled_once_and_never_uses_fallback<br>tests/unit/test_f12_recovery.py::test_probe_cannot_skip_incompatible_first_enabled_for_healthy_backup | tests/live/test_real_providers.py<br>tests/integration/test_f8_probe.py |
| T26 | tests/live/test_f12_real_routing.py::test_filtered_choice_reaches_actual_provider<br>tests/live/test_f12_real_routing.py::test_controlled_failure_then_actual_backup | tests/live/test_f10_acceptance.py<br>tests/live/test_real_providers.py<br>tests/integration/test_bug002_common.py |
| T27 |  | tests/unit/test_bug002_isolation.py<br>tests/unit/test_bug002_registry.py<br>tests/integration/test_bug002_common.py |
| T28 |  | tests/live/test_f10_capacity.py |

## 待核对项
- Root final regression and8 real L02/L05 nodes not executed by acceptance agent.
- T12 mixed-stage candidate rejection permutation has no standalone multi-stage test yet (single-stage variants covered).
- T19 new parametrization covers order/disabled/group budget/excluded enabled/recovery; Provider ref/address and Counter version change rely existing regressions but need confirm endpoint/group semantics after fixture migration.
- New historical nullable routing test added after last PG batch; root full run must execute it.
- Legacy live L01/L03/L04 route metadata enhancements requested from legacy agent; await their change/verification.

T12补充：test_mixed_rejection_stage_is_independent_of_candidate_order验证停用/能力/输出/上下文混合原因的24种排列，实际单元结果见f12-unit-final-mixed.log。
