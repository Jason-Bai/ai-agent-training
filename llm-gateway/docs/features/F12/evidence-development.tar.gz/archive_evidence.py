from pathlib import Path
import gzip,hashlib,json,tarfile,shutil,xml.etree.ElementTree as ET
import yaml
p=Path.cwd();w=Path(Path('/tmp/llmgw-f12-work-path').read_text());dest=p/'docs/features/F12'
manifest=json.loads((w/'source-pre-full-manifest.json').read_text())
assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
protected=json.loads((w/'private-file-preservation.json').read_text());assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==h for n,h in protected.items())
base=json.loads((w/'baseline-manifest.json').read_text());history=[n for n in base if n.startswith('docs/features/') and not n.startswith('docs/features/F12/')]
assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==base[n] for n in history)
root=ET.parse(w/'full.xml').getroot();cases=root.findall('.//testcase');live=[c for c in cases if c.get('classname','').startswith('tests.live.')]
assert len(cases)==2497 and len(live)==42
assert not root.findall('.//failure') and not root.findall('.//error') and not root.findall('.//skipped')
secrets=[]
cred=yaml.safe_load((p/'config/credentials.yaml').read_text())
for value in cred.get('credentials',{}).values():
 key=value.get('api_key')
 if isinstance(key,str) and len(key)>=12:secrets.append(key.encode())
def check(data,name):
 assert not any(s in data for s in secrets), 'Private credential detected: '+name
# Preserve original runtime migration privately; include only a safe receipt.
for source,name in [('full.log','evidence-full.log'),('full-receipt.json','evidence-full.json'),('real-f12-third.log','evidence-real-routing.log'),('capacity-summary.json','evidence-capacity-summary.json'),('final-node-mapping.json','evidence-node-mapping.json'),('runtime-config-migration.json','evidence-runtime-config-migration.json'),('source-pre-full-manifest.json','evidence-full-source-manifest.json')]:
 data=(w/source).read_bytes();check(data,source);(dest/name).write_bytes(data)
for source,name in [('full.xml','evidence-full.xml.gz'),('real-f12-third.xml','evidence-real-routing.xml.gz')]:
 data=(w/source).read_bytes();check(data,source)
 with gzip.open(dest/name,'wb') as out:out.write(data)
logs=[f for f in w.glob('*.log') if f.name!='full.log']
extras=[w/n for n in ('legacy-node-mapping.json','legacy-tests-changed.json','f12-test-coverage.json','f12-test-coverage.md','capacity-readonly-samples.jsonl','development-continuation-selection.json','archive_evidence.py') if (w/n).exists()]
with tarfile.open(dest/'evidence-development.tar.gz','w:gz') as out:
 for f in logs+extras:
  check(f.read_bytes(),f.name);out.add(f,arcname=f.name,recursive=False)
allowed_prefix=('availability-','wire-','response-final-','http-failure-','failure-scene-','f10-capacity','f11-provider-','mock-')
allowed_names={'observed.json','f11-counts.json','mock-lifecycle.json'}
raw=[]
for folder in ('pytest-full','pytest-real-f12-third'):
 for f in (w/folder).rglob('*.json'):
  if f.is_file() and not f.is_symlink() and (f.name.startswith(allowed_prefix) or f.name in allowed_names):
   if any(parent.is_symlink() for parent in f.parents if parent.is_relative_to(w)):continue
   raw.append(f)
records=[]
with tarfile.open(dest/'evidence-raw.tar.gz','w:gz') as out:
 for f in sorted(raw):
  data=f.read_bytes();rel=str(f.relative_to(w));check(data,rel)
  out.add(f,arcname=rel,recursive=False);records.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(dest/'evidence-raw-manifest.json').write_text(json.dumps(records,indent=2))
cap=next(f for f in raw if f.name=='f10-capacity.json');data=cap.read_bytes();check(data,str(cap))
with gzip.open(dest/'evidence-capacity.json.gz','wb') as out:out.write(data)
summary={'tests':len(cases),'live_nodes':len(live),'non_live_nodes':len(cases)-len(live),'failures':0,'errors':0,'skipped':0,'source_files_unchanged':len(manifest),'historical_documents_unchanged':len(history),'private_files_unchanged':True,'raw_artifacts':len(raw),'development_logs':len(logs),'runtime_config':'structure migrated, original Mock bindings preserved','scope':'single worker; owned isolated test PG/Gateway; two true protocols share DeepSeek; no production or supplier-invoice reconciliation claim'}
(dest/'evidence-verification.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,ensure_ascii=False))
