"""Test-side transport observation; no production request behavior changes."""


def install(app,directory,monkeypatch):
    """Attach transport observation after the application's trusted admission."""
