from pathlib import Path
import asyncio, json, sys, time
from datetime import datetime,timezone
sys.path.insert(0,'src')
import psycopg
from psycopg.rows import dict_row
from persistence.database import Database,load_database_config
from persistence.trace_query import read_trace
from persistence.billing_query import read_detail,read_summary
w=Path(Path('/tmp/llmgw-f13-work-path').read_text().strip())
p=next(x for x in (w/'pytest-capacity-followup').iterdir() if x.is_dir() and not x.is_symlink())
config=load_database_config(p/'config'); password=Path(config.password_file).read_text().rstrip('\n')
started=datetime.fromisoformat(json.loads((w/'capacity-followup-started.json').read_text())['started_at']).timestamp()
def safe(row):return {k:v for k,v in row.items() if k!='input_snapshot'}
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str)+'\n')
async def projections(rid,agent):
 db=Database(config,p/'config')
 try:
  t=await read_trace(db,rid,agent);b=await read_detail(db,agent,rid)
  return {'trace':t.model_dump(mode='json'),'bill':b}
 finally:await db.close()
seen=set();final=False
while time.time()-started<680:
 try:
  with psycopg.connect(host=config.host,port=config.port,user=config.username,password=password,dbname=config.name,connect_timeout=2,row_factory=dict_row) as sql:
   sql.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
   failures=sql.execute("SELECT * FROM tb_llm_request WHERE status='failed'").fetchall()
   for row in failures:
    rid=str(row['request_id'])
    if rid in seen:continue
    attempts=sql.execute('SELECT * FROM tb_llm_attempt WHERE request_pk=%s ORDER BY attempt_no',(row['id'],)).fetchall()
    bills=sql.execute('SELECT * FROM tb_billing_attempt WHERE request_pk=%s ORDER BY attempt_no',(row['id'],)).fetchall()
    events=sql.execute('SELECT * FROM tb_llm_stream_event WHERE request_pk=%s ORDER BY seq',(row['id'],)).fetchall()
    value={'captured_at':datetime.now(timezone.utc).isoformat(),'source':'executor read-only diagnostic SQL; executing test source unchanged','sql_request':safe(row),'sql_attempts':[safe(a) for a in attempts],'sql_bills':bills,'sql_events':events}
    value.update(asyncio.run(projections(rid,row['agent_id'])))
    dump(p/('failure-full-'+rid+'.json'),value);seen.add(rid)
   state=json.loads((p/'observed.json').read_text())
   if time.time()-started>605 and state.get('active_requests')==0:
    tables={}
    for table in ['tb_llm_request','tb_llm_attempt','tb_billing_attempt','tb_billing_operation']:
     tables[table]=[safe(x) for x in sql.execute('SELECT * FROM '+table).fetchall()]
    dump(p/'diagnostic-final-sql.json',{'captured_at':datetime.now(timezone.utc).isoformat(),'source':'read-only diagnostic, before test teardown; no credentials or input_snapshot','observed_resources':state,'tables':tables});final=True
  if final:break
 except psycopg.OperationalError:break
 time.sleep(.5)
dump(w/'capacity-followup-diagnostic-receipt.json',{'failed_request_ids_captured':sorted(seen),'final_sql_captured':final,'executing_source_modified':False,'read_only':True})
print('captured failures',len(seen),'final SQL',final)
