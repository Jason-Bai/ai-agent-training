"""Read-only evidence collection from this run's disposable capacity DB only."""
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from time import monotonic

PROJECT=Path('/Users/baiyu/workspaces/githubs/ai-agent-training/projects/llm-gateway')
sys.path[:0]=[str(PROJECT/'src'),str(PROJECT/'tests')]
from sqlalchemy import text
from persistence.database import Database, load_database_config
from persistence.trace_query import read_trace
from utils.json_codec import dumps

ROOT=Path(Path('/tmp/llmgw-f11-diagnostic-r2-path').read_text().strip())
OUT=ROOT/'capacity-failed-traces'
OUT.mkdir(exist_ok=True)

async def main():
    seen=set();started=monotonic();errors=[];reads=[]
    while monotonic()-started<1200 and not (ROOT/'full.exit').exists():
        dirs=[p for p in (ROOT/'pytest-full').glob('test_real_capacity*') if p.is_dir() and not p.is_symlink()]
        if not dirs: break
        directory=dirs[0]
        if (directory/'f10-capacity.json').exists():break
        observed=directory/'observed.json'
        if not observed.exists() or json.loads(observed.read_text()).get('active_requests',0)==0:
            await asyncio.sleep(3);continue
        config_dir=directory/'config'
        config=load_database_config(config_dir)
        assert config.host=='127.0.0.1' and config.name.startswith('case_') and config.username=='gateway_test'
        database=Database(config,config_dir)
        begin=monotonic()
        try:
            async with database.transaction() as session:
                await session.execute(text('SET TRANSACTION READ ONLY'))
                rows=(await session.execute(text("SELECT request_id,agent_id FROM tb_llm_request WHERE status='failed' AND ended_at < clock_timestamp()-interval '1 second'"))).mappings().all()
            for row in rows:
                rid=str(row['request_id'])
                if rid in seen: continue
                trace=await read_trace(database,rid,row['agent_id'])
                async with database.transaction() as session:
                    await session.execute(text('SET TRANSACTION READ ONLY'))
                    pk=await session.scalar(text('SELECT id FROM tb_llm_request WHERE request_id=:rid'),{'rid':rid})
                    bills=(await session.execute(text('SELECT attempt_no,state,reserved_amount,agent_charge,supplier_cost FROM tb_billing_attempt WHERE request_pk=:pk ORDER BY attempt_no'),{'pk':pk})).mappings().all()
                    events=(await session.execute(text('SELECT seq,event_type,payload FROM tb_llm_stream_event WHERE request_pk=:pk ORDER BY seq'),{'pk':pk})).mappings().all()
                (OUT/(rid+'.json')).write_text(dumps(dict(request_id=rid,trace=trace.model_dump(mode='json'),
                    bills=[dict(x) for x in bills],events=[dict(x) for x in events],source='independent read-only SQL snapshot; no Provider calls')))
                seen.add(rid)
            reads.append(dict(observed_at=datetime.now(timezone.utc).isoformat(),elapsed_ms=(monotonic()-begin)*1000,new_total=len(seen)))
        except Exception as exc:
            errors.append(dict(observed_at=datetime.now(timezone.utc).isoformat(),exception=type(exc).__name__))
        finally:
            await database.close()
        await asyncio.sleep(5)
    (OUT/'collector-receipt.json').write_text(json.dumps(dict(scope='test-owned capacity database only; read-only, transient single extra connection during active execution',captured=len(seen),reads=reads,errors=errors),indent=2))
    print(json.dumps(dict(captured_failed_traces=len(seen),errors=errors)))

if __name__=='__main__':asyncio.run(main())
