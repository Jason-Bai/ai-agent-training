"""Exact recorded synthetic upstream bodies; bypass Gateway and Provider SSE parser."""
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from time import monotonic

PROJECT=Path('/Users/baiyu/workspaces/githubs/ai-agent-training/projects/llm-gateway')
sys.path[:0]=[str(PROJECT/'src'),str(PROJECT/'tests'),str(PROJECT/'tests/live')]
from test_real_providers import real_registry
from providers.factory import ProviderClients

ROOT=Path(Path('/tmp/llmgw-f11-diagnostic-path').read_text().strip())
rows=[json.loads(x) for x in (ROOT/'diagnostic-wire.jsonl').read_text().splitlines()]

async def main():
    clients=ProviderClients(real_registry())
    async with clients.open() as instances:
        # Both real adapters use this same host/key. Reuse authorized direct HTTP
        # client to remove SDK SSE parsing as well as all Gateway execution.
        client=instances['deepseek-main'].client
        for label,origin in (('D07-direct-backup-stream','D06-backup-stream'),
                             ('D08-direct-primary-stream','D03-primary-stream')):
            rid=json.loads((ROOT/(origin+'.json')).read_text())['request_id']
            request=next(x for x in rows if x.get('request_id')==rid and x['kind']=='upstream_request')
            result=dict(label=label,source_request_id=rid,scope='direct raw HTTP; no Gateway/SDK SSE parser/retries',
                        observed_at=datetime.now(timezone.utc).isoformat(),body=request['body'],path=request['path'],
                        total_timeout_seconds=30,lines=[])
            started=monotonic()
            try:
                async with asyncio.timeout(30):
                    async with client.stream('POST',request['path'].lstrip('/'),json=request['body'],timeout=30) as response:
                        result.update(http_status=response.status_code,headers_ms=(monotonic()-started)*1000)
                        async for line in response.aiter_lines():
                            if line:
                                result['lines'].append(dict(elapsed_ms=(monotonic()-started)*1000,line=line))
                        result['body_eof']=True
            except (Exception,asyncio.CancelledError) as exc:
                # Only exception class; no Key/header/HTTP request repr recorded.
                result['exception']=type(exc).__name__
            result['elapsed_ms']=(monotonic()-started)*1000
            (ROOT/(label+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
            print(json.dumps(dict(label=label,http_status=result.get('http_status'),exception=result.get('exception'),
                     elapsed_ms=result['elapsed_ms'],line_count=len(result['lines']),
                     events=[x['line'] for x in result['lines'] if x['line'].startswith('event:')]),ensure_ascii=False),flush=True)

if __name__=='__main__': asyncio.run(main())
