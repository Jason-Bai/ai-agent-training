
from contextlib import asynccontextmanager
import asyncio, json
from contextvars import ContextVar
from utils.json_codec import dumps
from datetime import datetime, timezone
from pathlib import Path
from main import create_app as build
from settings import Settings
ROOT=Path(__file__).parent
OBSERVATION_ERRORS=[]
def record_json(path,value):
    try:
        path.write_text(dumps(value))
    except (OSError,TypeError,ValueError) as exc:
        OBSERVATION_ERRORS.append(type(exc).__name__)
def create_app():
    app=build(settings=Settings(env='test',_env_file=None), config_dir=ROOT/'config')
    # Associate final upstream Responses snapshots with the executing request.
    # This is test observation only; the original parser/result is retained.
    from providers import streaming, openai_compatible, deepseek
    original_frames=streaming.frames
    async def observed_frames(lines):
        observed=[]
        rid=current_request.get()
        try:
            async for event,data in original_frames(lines):
                try: observed.append(dict(event=event,data=json.loads(data)))
                except ValueError: observed.append(dict(event=event,data=data))
                yield event,data
        finally:
            if rid is not None:
                record_json(ROOT/('wire-'+rid+'.json'),observed)
    streaming.frames=observed_frames
    original_status=deepseek.error_for_status
    def observed_status(status,headers=None):
        error=original_status(status,headers)
        rid=current_request.get()
        if rid is not None:
            record_json(ROOT/('http-failure-'+rid+'.json'),dict(status=status,code=error.code))
        return error
    deepseek.error_for_status=observed_status
    openai_compatible.error_for_status=observed_status
    original_parse=streaming.parse_responses_response
    current_request=ContextVar('f10_request',default=None)
    begin=app.state.storage.begin_attempt
    async def begin_observed(trace,attempt,**kwargs):
        await begin(trace,attempt,**kwargs)
        current_request.set(trace.request_id)
    app.state.storage.begin_attempt=begin_observed
    def parse_observed(raw):
        result=original_parse(raw)
        rid=current_request.get()
        if rid is not None and result.upstream_status=='completed':
            record_json(ROOT/('response-final-'+rid+'.json'),
                        dict(text=result.text,raw=raw,usage=raw.get('usage')))
        return result
    streaming.parse_responses_response=parse_observed
    openai_compatible.parse_responses_response=parse_observed
    original_chat=deepseek.parse_response
    def chat_observed(raw):
        result=original_chat(raw)
        rid=current_request.get()
        if rid is not None:
            record_json(ROOT/('response-final-'+rid+'.json'),
                        dict(text=result.text,raw=raw,usage=raw.get('usage')))
        return result
    deepseek.parse_response=chat_observed
    original=app.router.lifespan_context
    @asynccontextmanager
    async def lifespan(app):
        async with original(app):
            async def snapshot():
                while True:
                    manager=app.state.streaming_manager
                    concurrency=app.state.concurrency_limiter.snapshot()
                    values=dict(observation_errors=len(OBSERVATION_ERRORS),snapshot_at=datetime.now(timezone.utc).isoformat(), active_generations=len(manager.tasks), subscriptions=len(manager.subscriptions),
                                cleanup_tasks=len(manager.cleanup_tasks), cancellations=len(manager.cancellations),
                                active_requests=concurrency['active_requests'], agent_requests=concurrency['agents'],
                                trace_requests=len(app.state.traces.requests), trace_attempts=len(app.state.traces.attempts))
                    staging=ROOT/'observed.tmp'
                    staging.write_text(json.dumps(values))
                    staging.replace(ROOT/'observed.json')
                    await asyncio.sleep(1)
            task=asyncio.create_task(snapshot())
            try: yield
            finally:
                task.cancel()
                await asyncio.gather(task,return_exceptions=True)
    app.router.lifespan_context=lifespan
    return app


previous_create_app = create_app
from contextvars import ContextVar
from time import monotonic
diagnostic_context = ContextVar('diagnostic_context', default=None)
def create_app():
    app = previous_create_app()
    def record(kind, **fields):
        context = diagnostic_context.get() or {}
        entry = dict(observed_at=datetime.now(timezone.utc).isoformat(),
                     monotonic=monotonic(), kind=kind, **context, **fields)
        with (ROOT/'diagnostic-wire.jsonl').open('a') as out:
            out.write(dumps(entry)+'\n')
    old_begin = app.state.storage.begin_attempt
    async def begin(trace, attempt, **kwargs):
        await old_begin(trace, attempt, **kwargs)
        diagnostic_context.set(dict(request_id=trace.request_id, attempt_no=attempt.number,
                                    model=attempt.model, protocol=attempt.api_protocol))
        record('attempt_begin', reason=attempt.reason)
    app.state.storage.begin_attempt = begin
    from providers import streaming
    import httpx2
    old_lines = httpx2.Response.aiter_lines
    async def raw_lines(response):
        try:
            async for line in old_lines(response):
                record('raw_http_line', line=line)
                yield line
        finally:
            record('raw_http_lines_closed')
    httpx2.Response.aiter_lines = raw_lines
    old_frames = streaming.frames
    async def wire(lines):
        try:
            async for event, data in old_frames(lines):
                record('upstream_frame', event=event, data=data)
                yield event, data
        finally:
            record('upstream_frames_closed')
    streaming.frames = wire
    def wrap(provider):
        original_complete, original_stream = provider.complete, provider.stream
        async def complete(*args, **kwargs):
            record('provider_enter', operation='complete', timeout_seconds=kwargs['timeout_seconds'])
            try:
                result = await original_complete(*args, **kwargs)
                record('provider_result', text=result.text, usage=result.usage.model_dump() if result.usage else None,
                       finish_reason=result.finish_reason, upstream_status=result.upstream_status)
                return result
            except BaseException as exc:
                record('provider_exception', exception=type(exc).__name__, code=getattr(exc,'code',None),
                       upstream_http_status=getattr(exc,'upstream_http_status',None),
                       transient=getattr(exc,'transient',None), retry_after_seconds=getattr(exc,'retry_after_seconds',None))
                raise
            finally:
                record('provider_exit', operation='complete')
        async def stream(*args, **kwargs):
            record('provider_enter', operation='stream', timeout_seconds=kwargs['timeout_seconds'])
            iterator = original_stream(*args, **kwargs)
            try:
                async for item in iterator:
                    record('provider_stream_event', value=item.model_dump(mode='json'))
                    yield item
            except BaseException as exc:
                record('provider_exception', exception=type(exc).__name__, code=getattr(exc,'code',None))
                raise
            finally:
                await iterator.aclose()
                record('provider_exit', operation='stream')
        provider.complete, provider.stream = complete, stream
        client = getattr(provider.client, '_client', provider.client)
        async def requested(request):
            record('upstream_request', method=request.method, host=request.url.host, path=request.url.path,
                   body=json.loads(request.content))
        async def responded(response):
            record('upstream_headers', status=response.status_code,
                   retry_after=response.headers.get('retry-after'))
        client.event_hooks.setdefault('request', []).append(requested)
        client.event_hooks.setdefault('response', []).append(responded)
    original = app.router.lifespan_context
    @asynccontextmanager
    async def lifespan(app):
        async with original(app):
            for provider in {id(p):p for p in app.state.providers.values()}.values(): wrap(provider)
            yield
    app.router.lifespan_context = lifespan
    return app
