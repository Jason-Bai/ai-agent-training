"""User-authorized real diagnosis only; no acceptance gates or product files changed."""
import asyncio
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from time import monotonic

PROJECT = Path('/Users/baiyu/workspaces/githubs/ai-agent-training/projects/llm-gateway')
sys.path[:0] = [str(PROJECT/'src'), str(PROJECT/'tests'), str(PROJECT/'tests/live')]
from f10_support import Environment, CredentialHeaders, BOOTSTRAP, frames
from postgres_support import PostgresServer, write_config, migrate
from test_real_providers import real_registry
from f4_cases import SCHEMA, CONTEXT
from services.models import DEFAULT_CONFIG_DIR

ROOT = Path('/tmp/llmgw-f11-diagnostic-path').read_text().strip()
ROOT = Path(ROOT)/'raw-line-repro'
ROOT.mkdir(exist_ok=False)

OBSERVER = r'''
previous_create_app = create_app
from contextvars import ContextVar
from time import monotonic
diagnostic_context = ContextVar('diagnostic_context', default=None)
def create_app():
    app = previous_create_app()
    def record(kind, **fields):
        context = diagnostic_context.get() or {}
        entry = dict(observed_at=datetime.now(timezone.utc).isoformat(),
                     monotonic=monotonic(), kind=kind, **context, **fields)
        with (ROOT/'diagnostic-wire.jsonl').open('a') as out:
            out.write(dumps(entry)+'\n')
    old_begin = app.state.storage.begin_attempt
    async def begin(trace, attempt, **kwargs):
        await old_begin(trace, attempt, **kwargs)
        diagnostic_context.set(dict(request_id=trace.request_id, attempt_no=attempt.number,
                                    model=attempt.model, protocol=attempt.api_protocol))
        record('attempt_begin', reason=attempt.reason)
    app.state.storage.begin_attempt = begin
    from providers import streaming
    import httpx2
    old_bytes = httpx2.Response.aiter_bytes
    async def raw_bytes(response, *args, **kwargs):
        async for chunk in old_bytes(response, *args, **kwargs):
            record('raw_http_bytes', size=len(chunk), hex=chunk.hex())
            yield chunk
    httpx2.Response.aiter_bytes = raw_bytes
    old_lines = httpx2.Response.aiter_lines
    async def raw_lines(response):
        try:
            async for line in old_lines(response):
                record('raw_http_line', line=line)
                yield line
        finally:
            record('raw_http_lines_closed')
    httpx2.Response.aiter_lines = raw_lines
    old_frames = streaming.frames
    async def wire(lines):
        try:
            async for event, data in old_frames(lines):
                record('upstream_frame', event=event, data=data)
                yield event, data
        finally:
            record('upstream_frames_closed')
    streaming.frames = wire
    def wrap(provider):
        original_complete, original_stream = provider.complete, provider.stream
        async def complete(*args, **kwargs):
            record('provider_enter', operation='complete', timeout_seconds=kwargs['timeout_seconds'])
            try:
                result = await original_complete(*args, **kwargs)
                record('provider_result', text=result.text, usage=result.usage.model_dump() if result.usage else None,
                       finish_reason=result.finish_reason, upstream_status=result.upstream_status)
                return result
            except BaseException as exc:
                record('provider_exception', exception=type(exc).__name__, code=getattr(exc,'code',None),
                       upstream_http_status=getattr(exc,'upstream_http_status',None),
                       transient=getattr(exc,'transient',None), retry_after_seconds=getattr(exc,'retry_after_seconds',None))
                raise
            finally:
                record('provider_exit', operation='complete')
        async def stream(*args, **kwargs):
            record('provider_enter', operation='stream', timeout_seconds=kwargs['timeout_seconds'])
            iterator = original_stream(*args, **kwargs)
            try:
                async for item in iterator:
                    record('provider_stream_event', value=item.model_dump(mode='json'))
                    yield item
            except BaseException as exc:
                record('provider_exception', exception=type(exc).__name__, code=getattr(exc,'code',None))
                raise
            finally:
                await iterator.aclose()
                record('provider_exit', operation='stream')
        provider.complete, provider.stream = complete, stream
        client = getattr(provider.client, '_client', provider.client)
        async def requested(request):
            record('upstream_request', method=request.method, host=request.url.host, path=request.url.path,
                   body=json.loads(request.content))
        async def responded(response):
            record('upstream_headers', status=response.status_code,
                   retry_after=response.headers.get('retry-after'))
        client.event_hooks.setdefault('request', []).append(requested)
        client.event_hooks.setdefault('response', []).append(responded)
    original = app.router.lifespan_context
    @asynccontextmanager
    async def lifespan(app):
        async with original(app):
            for provider in {id(p):p for p in app.state.providers.values()}.values(): wrap(provider)
            yield
    app.router.lifespan_context = lifespan
    return app
'''

def save(name, value):
    (ROOT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str))

async def execute(env, label, model, mode):
    if mode == 'probe':
        data = None
    else:
        data = dict(model=model, prompt=dict(name='context_answer',version='1.2.0' if mode=='structured' else '1.1.0',
                    variables=dict(context=CONTEXT if mode=='structured' else '订单 A123 的商品为充电器。')),
                    messages=[dict(role='user', content='提取订单号、商品信息和备注；备注未知时使用 null。' if mode=='structured' else '订单 A123 的商品是什么？请简短回答。')],
                    max_output_tokens=128, timeout_seconds=30)
        if mode=='structured': data['response_schema'] = deepcopy(SCHEMA)
    result = dict(label=label, model=model, mode=mode, started_at=datetime.now(timezone.utc).isoformat(), request=data)
    start = monotonic()
    events = []
    if mode=='streaming':
        created = await env.client.post('/v1/llm/stream',json=data)
        rid=created.headers['x-request-id']
        result['create_status']=created.status_code
        if created.status_code==202:
            async with env.client.stream('GET',f'/v1/llm/stream/{rid}/events') as response:
                result['http_status']=response.status_code
                async for seq,name,payload in frames(response):
                    events.append(dict(seq=seq,event=name,data=payload,elapsed_ms=(monotonic()-start)*1000))
        else:
            result['response']=created.json()
        result['events']=events
    else:
        response = await env.client.post(f'/v1/models/{model}/health' if mode=='probe' else '/v1/llm',json=data)
        rid=response.headers['x-request-id']
        result.update(http_status=response.status_code,response=response.json())
    result.update(request_id=rid,elapsed_ms=(monotonic()-start)*1000)
    async with asyncio.timeout(8):
        while True:
            traced=await env.client.get(f'/v1/traces/{rid}')
            if traced.status_code==200 and traced.json()['data']['status'] in ('completed','failed','canceled'):
                break
            await asyncio.sleep(.1)
    result['trace_status']=traced.status_code
    result['trace']=traced.json()
    result['invariants']=await env.verify(rid,expected_agent='a')
    await env.assert_balances()
    save(label+'.json',result)
    trace=result['trace'].get('data',{})
    print(json.dumps(dict(label=label,request_id=rid,status=trace.get('status'),error_code=trace.get('error_code'),
                         attempts=[dict(n=a['attempt_no'],reason=a['reason'],code=a['error_code'],duration_ms=a['provider_duration_ms']) for a in trace.get('attempts',[])],
                         recovery=trace.get('recovery'),elapsed_ms=result['elapsed_ms']),ensure_ascii=False),flush=True)
    return result

async def main():
    pg = await asyncio.to_thread(lambda: PostgresServer().start())
    name=pg.create_database()
    env=Environment(pg,name,ROOT,concurrency=dict(max_requests=20,max_requests_per_agent=5))
    try:
        registry=real_registry()
        write_config(env.config,pg,name,registry)
        (env.config/'credentials.yaml').symlink_to(DEFAULT_CONFIG_DIR/'credentials.yaml')
        (env.config/'prices.yaml').symlink_to(DEFAULT_CONFIG_DIR/'prices.yaml')
        (ROOT/'f10_bootstrap.py').write_text(BOOTSTRAP+'\n'+OBSERVER)
        save('effective-policy.json',dict(scope='diagnosis; historical real test registry; no fallback override',
             recovery=registry.recovery.model_dump(),models={k:v.model_dump(mode='json') for k,v in registry.models.items()},concurrency=env.concurrency))
        await asyncio.to_thread(migrate,env.config)
        for agent in ('a','b'):
            await env.cli('create-agent',agent,'F11 diagnostic '+agent)
            token=await env.cli('issue',agent)
            headers=CredentialHeaders(Authorization='Bearer '+token)
            if agent=='a': env.headers=headers
            else: env.other_headers=headers
            await env.cli('deposit',agent,'10000','--operation-id','initial-'+agent)
        await env.start()
        for label in ('D12-backup-stream-bytes','D13-backup-stream-bytes','D14-backup-stream-bytes'):
            result = await execute(env,label,'general-backup','streaming')
            if result['trace'].get('data',{}).get('status') == 'failed':
                break  # bounded diagnosis: stop at first captured failure, never acceptance reruns
        await asyncio.sleep(1.1)
        save('final-resources.json',await env.sample())
    finally:
        await env.stop()
        await asyncio.to_thread(pg.drop_database,name)
        await asyncio.to_thread(pg.close)

if __name__=='__main__': asyncio.run(main())
