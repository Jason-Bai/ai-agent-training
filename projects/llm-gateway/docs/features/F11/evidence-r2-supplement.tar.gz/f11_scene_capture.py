import asyncio,json
from pathlib import Path
import pytest_asyncio
from utils.json_codec import dumps

@pytest_asyncio.fixture(autouse=True)
async def preserve_f11_scene(f11_real_environment):
    env=f11_real_environment
    try:
        yield
    finally:
        scenes=[]
        for path in env.directory.glob('availability-*.json'):
            rid=json.loads(path.read_text())['request_id']
            trace=None
            async with asyncio.timeout(8):
                while True:
                    response=await env.client.get('/v1/traces/'+rid)
                    if response.status_code==404:response=await env.client.get('/v1/traces/'+rid,headers=env.other_headers)
                    assert response.status_code==200
                    trace=response.json()['data']
                    if trace['status'] in ('completed','failed','canceled'):break
                    await asyncio.sleep(.02)
            def sql():
                with env.pg.connect(env.name) as db:
                    row=db.execute('SELECT id,status,error_code,agent_id FROM tb_llm_request WHERE request_id=%s',(rid,)).fetchone()
                    bills=db.execute('SELECT attempt_no,state,agent_charge,supplier_cost FROM tb_billing_attempt WHERE request_pk=%s ORDER BY attempt_no',(row[0],)).fetchall()
                    events=db.execute('SELECT seq,event_type,payload FROM tb_llm_stream_event WHERE request_pk=%s ORDER BY seq',(row[0],)).fetchall()
                    return dict(request=list(row),bills=[list(x) for x in bills],events=[list(x) for x in events])
            saved=await asyncio.to_thread(sql)
            assert saved['request'][1]==trace['status']
            assert len(saved['bills'])==len(trace['attempts'])
            assert all(b[1]!='reserved' for b in saved['bills'])
            scenes.append(dict(request_id=rid,trace=trace,sql=saved))
        await env.assert_balances()
        async with asyncio.timeout(8):
            while True:
                counts=json.loads((env.directory/'f11-counts.json').read_text())
                if counts==dict(active_requests=0,agents={}):break
                await asyncio.sleep(.02)
        (env.directory/'supplement-scenes.json').write_text(dumps(dict(scenes=scenes,final_counts=counts,balances_verified=True)))
