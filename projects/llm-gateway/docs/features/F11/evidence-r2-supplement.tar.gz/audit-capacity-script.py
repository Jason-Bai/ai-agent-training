"""Reproducible read-only audit of immutable real observations, not a live rerun."""
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import sys

PROJECT=Path('/Users/baiyu/workspaces/githubs/ai-agent-training/projects/llm-gateway')
sys.path[:0]=[str(PROJECT/'src'),str(PROJECT/'tests')]
from upstream_availability import classify_upstream_failure, _unfinished_text, _error_body_only

ROOT=Path(Path('/tmp/llmgw-f11-diagnostic-r2-path').read_text().strip())
CAP=next(p for p in (ROOT/'pytest-full').glob('test_real_capacity*/f10-capacity.json') if not p.parent.is_symlink())
report=json.loads(CAP.read_text())

def drained(value):
    return all(value.get(k)==0 for k in ('active_requests','active_generations','cleanup_tasks','cancellations','subscriptions')) and value.get('agent_requests')=={}

def body_wait(trace, obs, text):
    """Ordinary body-read deadline: facts unavailable to the narrow SSE classifier."""
    try:
        if (trace['operation'] not in ('completion','provider_probe') or trace['status']!='failed'
            or trace['request_id']!=obs['request_id'] or len(trace['attempts'])!=1 or len(obs['attempts'])!=1
            or trace['error_stage']!='provider' or trace['delivery_error_code'] is not None
            or trace['cancellation']['cleanup_error_code'] is not None or trace['cancellation']['requested_at'] is not None
            or not drained(obs['drained']) or obs['accounting_verified'] is not True or obs['lifecycle_verified'] is not True):return None
        a=trace['attempts'][0];w=obs['attempts'][0];budget=trace['timeout_seconds']*1000
        expected='provider_timeout' if trace['operation']=='provider_probe' else 'request_timeout'
        if (trace['error_code']!=expected or a['error_code']!=expected or a['status']!='failed'
            or a['provider_entered'] is not True or a['cleanup_error_code'] is not None
            or a['usage'] is not None or trace['usage']!={'known_subtotal':None,'unknown_attempts':[1]}
            or a['finish_reason'] is not None or a['upstream_status'] not in (None,'in_progress')
            or a['upstream_finish_reason'] is not None or a['api_protocol']!=w['protocol']
            or w['attempt_no']!=a['attempt_no'] or a['attempt_no']!=1
            or w['http_status']!=200 or w['read_closed'] is not True or w['read_cancelled'] is not True
            or w['typed_text']!='' or text not in (None,'')
            or w['upstream_http_status'] is not None
            or w['provider_error_code'] not in (None,'provider_timeout')
            or w['transient'] is not None
            or not budget-1000<=w['ended_ms']-w['started_ms']<=budget+1000
            or not budget-1000<=trace['timing']['request_duration_ms']<=budget+2000
            or not 0<=w['started_ms']<=w['http_headers_ms']<=w['ended_ms']):return None
        raw=w['raw_text']
        if any(char not in ' \t\r\n' for char in raw):return None
        if type(w['transport_chunks']) is not int or w['transport_chunks']<0:return None
        if (raw=='' and w['transport_chunks']!=0) or (raw!='' and w['transport_chunks']==0):return None
        return dict(request_id=trace['request_id'],kind='manual_upstream_body_wait',operation=trace['operation'],
                    http_status=200,body_bytes=len(raw.encode()),provider_elapsed_ms=w['ended_ms']-w['started_ms'],
                    source='actual saved full Trace + HTTP read cancellation + SQL/billing + phase drain')
    except (KeyError,TypeError,ValueError):return None

def sql_scene_valid(scene):
    t=scene['trace'];bills=scene['bills'];events=scene['events'];attempts=t['attempts']
    if t['status']!='failed' or len(bills)!=len(attempts):return False
    if [b['attempt_no'] for b in bills]!=[a['attempt_no'] for a in attempts]:return False
    if any(b['state']!='pending' or b['agent_charge'] is not None or b['supplier_cost'] is not None for b in bills):return False
    if any(a['usage'] is not None or a['status']!='failed' for a in attempts):return False
    if t['operation']=='streaming':
        return bool(events) and [e['seq'] for e in events]==list(range(1,len(events)+1)) and events[-1]['event_type']=='response.failed' and sum(e['event_type'] in ('response.completed','response.failed','response.canceled') for e in events)==1
    return events==[]

def last_recovery_stall(record, verified, obs, after, trace=None):
    """One saved sample lacks full Trace; audit its recorded SQL summary explicitly."""
    if (record['status']!='failed' or record['mode'] not in ('streaming','text') or record['error_code']!='request_timeout'
        or verified['status']!='failed' or verified['error_code']!='request_timeout'
        or not drained(after) or verified['attempts']!=2 or verified['bill_states']!=['pending','pending']
        or len(obs['attempts'])!=2 or verified['server_timing']['error_stage']!='provider'
        or verified['server_timing']['cleanup_error_code'] is not None
        or verified['server_timing']['delivery_error_code'] is not None):return None
    first,last=obs['attempts']
    if (first['attempt_no']!=1 or first['http_status']!=503 or first['provider_error_code']!='provider_unavailable'
        or first['upstream_http_status']!=503 or first['transient'] is not True
        or first['typed_text']!='' or first['read_closed'] is not True or not _error_body_only(first['raw_text'])
        or last['attempt_no']!=2 or last['http_status']!=200 or last['read_closed'] is not True
        or last['read_cancelled'] is not True or last['provider_error_code'] is not None
        or last['upstream_http_status'] is not None):return None
    events=record['events']
    if not 29000<=sum(w['ended_ms']-w['started_ms'] for w in obs['attempts'])+verified['server_timing']['recovery_wait_ms']<=31000:return None
    if trace is not None:
        if (len(trace['attempts'])!=2 or trace['usage']!={'known_subtotal':None,'unknown_attempts':[1,2]}
            or [a['error_code'] for a in trace['attempts']]!=['provider_unavailable','request_timeout']
            or [a['reason'] for a in trace['attempts']]!=['initial','network_retry']
            or any(a['provider_entered'] is not True or a['cleanup_error_code'] is not None for a in trace['attempts'])):return None
    count=0;keepalive=False
    if record['mode']=='streaming':
        text,count,keepalive=_unfinished_text(last['raw_text'],last['protocol'])
        if ([e[0] for e in events]!=list(range(1,len(events)+1)) or events[-1][1]!='response.failed'
            or sum(e[1] in ('response.failed','response.completed','response.canceled') for e in events)!=1
            or text!=last['typed_text'] or text!=''.join(e[2]['delta'] for e in events if e[1]=='response.delta')
            or not 29000<=verified['server_timing']['stream_duration_ms']<=31000):return None
    else:
        if (trace is None or events or last['typed_text']!='' or any(c not in ' \t\r\n' for c in last['raw_text'])
            or (last['raw_text']=='' and last['transport_chunks']!=0)
            or not 29000<=trace['timing']['request_duration_ms']<=32000):return None
    return dict(request_id=record['request_id'],kind='manual_http_retry_then_'+('stream' if record['mode']=='streaming' else 'body')+'_stall',
                source='actual HTTP/SSE and recorded independent SQL/event/billing summary',
                limitation=None if trace is not None else 'full per-field Trace absent; no Trace was reconstructed',raw_frame_count=count,
                keepalive_observed=keepalive)

rows=[]
for phase in report['phases']+[report['sustained']]:
    assert drained(phase['after'])
    for r in phase['records']:
        if r['status']=='completed':continue
        rid=r['request_id'];v=phase['verified'][rid];obs=json.loads((CAP.parent/('availability-'+rid+'.json')).read_text())
        obs.update(drained=phase['after'],accounting_verified=True,lifecycle_verified=True)
        text=''.join(e[2]['delta'] for e in r['events'] if e[1]=='response.delta') if r['mode']=='streaming' else None
        saved=ROOT/'capacity-failed-traces'/(rid+'.json');proof=None
        if saved.exists():
            scene=json.loads(saved.read_text());assert sql_scene_valid(scene)
            proof=(classify_upstream_failure(scene['trace'],obs,downstream_text=text) or body_wait(scene['trace'],obs,text)
                   or last_recovery_stall(r,v,obs,phase['after'],scene['trace']))
            if proof and proof['kind']=='manual_upstream_body_wait':
                for key,value in [('raw_text','{}'),('raw_text','\u00a0'),('read_cancelled',False),('typed_text','leaked')]:
                    bad=deepcopy(obs);bad['attempts'][0][key]=value
                    assert body_wait(scene['trace'],bad,text) is None
        else:
            proof=last_recovery_stall(r,v,obs,phase['after'])
        rows.append(dict(request_id=rid,concurrency=phase['concurrency'],mode=r['mode'],proof=proof))

summary=dict(scope='post-run evidence audit; preserves original pytest failures; not a new live run',
             failed_capacity_requests=len(rows),classified=sum(r['proof'] is not None for r in rows),
             unresolved=[r['request_id'] for r in rows if r['proof'] is None],rows=rows,
             limitations=['One final mixed-recovery stream has SQL verification summary but no full per-field Trace. Its source distinction is explicit.',
                          'The frozen live gate intentionally did not implement ordinary body waits/mixed-recovery stalls; original capacity pytest remains failed.',
                          '600 seconds actually ran at concurrency 1 chosen using evidence available then; this audit does not relabel it as a 20-concurrency sustained run.'])
(ROOT/'postrun-capacity-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ('rows','limitations')},ensure_ascii=False))
