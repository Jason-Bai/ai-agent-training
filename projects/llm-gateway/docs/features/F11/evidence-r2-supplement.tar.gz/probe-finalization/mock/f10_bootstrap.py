
from pathlib import Path
from main import create_app as build
from settings import Settings
from providers.mock import MockProvider
ROOT=Path(__file__).parent
def create_app():
    return build(settings=Settings(env='test',_env_file=None),config_dir=ROOT/'config',provider=MockProvider(delay=11))
