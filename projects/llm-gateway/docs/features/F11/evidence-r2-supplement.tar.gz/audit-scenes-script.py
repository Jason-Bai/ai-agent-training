"""Correlate saved HTTP, SQL and resource scenes without changing their outcomes."""
import json
from pathlib import Path
import runpy

audit=runpy.run_path('/tmp/llmgw-f11-audit-r2.py')
ROOT=audit['ROOT'];rawroot=ROOT/'pytest-full'
classify=audit['classify_upstream_failure'];body_wait=audit['body_wait'];valid=audit['sql_scene_valid'];drained=audit['drained']
rows=[]
for path in rawroot.rglob('failure-scene-*.json'):
    if path.is_symlink():continue
    scene=json.loads(path.read_text());trace=scene['trace'];rid=scene['request_id']
    obs=json.loads((path.parent/('availability-'+rid+'.json')).read_text())
    if not valid(scene) or not drained(scene['drained']):
        rows.append(dict(directory=path.parent.name,request_id=rid,proof=None,
                         limitation='snapshot not yet a verified persisted terminal; no exemption issued'))
        continue
    obs.update(drained=scene['drained'],accounting_verified=True,lifecycle_verified=True)
    text=''.join(json.loads(e['payload'])['delta'] for e in scene['events'] if e['event_type']=='response.delta') if trace['operation']=='streaming' else None
    proof=classify(trace,obs,downstream_text=text) or body_wait(trace,obs,text)
    if proof is None and trace['operation']=='provider_probe':
        a=trace['attempts'];w=obs['attempts']
        if (len(a)==len(w)==1 and a[0]['reason']=='initial' and a[0]['error_code']==trace['error_code']=='provider_unavailable'
            and w[0]['http_status']==w[0]['upstream_http_status']==503 and w[0]['provider_error_code']=='provider_unavailable'
            and w[0]['read_closed'] is True and w[0]['transient'] is True and w[0]['typed_text']==''
            and trace['error_stage']=='provider' and trace['delivery_error_code'] is None
            and trace['cancellation']['cleanup_error_code'] is None
            and trace['usage']=={'known_subtotal':None,'unknown_attempts':[1]}):
            proof=dict(request_id=rid,kind='manual_probe_reports_upstream_unavailable',attempt_count=1,
                       source='actual HTTP503 + typed failure + saved SQL/Trace/billing + zero resources')
    rows.append(dict(directory=path.parent.name,request_id=rid,proof=proof))
f11=[]
for directory in rawroot.iterdir():
    if not directory.is_dir() or directory.is_symlink() or not (directory/'f11-counts.json').exists():continue
    requests=[]
    for path in directory.glob('availability-*.json'):
        obs=json.loads(path.read_text())
        failed=[dict(attempt_no=a['attempt_no'],http_status=a['http_status'],code=a['provider_error_code'],read_closed=a['read_closed']) for a in obs['attempts'] if a['provider_error_code'] is not None or a['read_cancelled']]
        if failed:requests.append(dict(request_id=obs['request_id'],attempts=failed))
    if not requests:continue
    f11.append(dict(directory=directory.name,requests=requests,final_counts=json.loads((directory/'f11-counts.json').read_text()),
                    classification='dependency prevented some success-scenario assertions; not relabeled as scenario success',
                    limitation='no per-request SQL snapshot retained for these six fixtures; prior same-product real six successes are separate evidence'))
result=dict(scope='post-run read-only scene audit; original 23 pytest failures retained',
            saved_scene_count=len(rows),classified_scenes=sum(x['proof'] is not None for x in rows),
            unresolved_scenes=[x['request_id'] for x in rows if x['proof'] is None],
            scenes=rows,f11_dependency_blocked_scenarios=f11)
(ROOT/'postrun-scenes-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(dict(saved_scenes=len(rows),classified_scenes=result['classified_scenes'],unresolved=result['unresolved_scenes'],f11_dependency_scenarios=len(f11)),ensure_ascii=False))
