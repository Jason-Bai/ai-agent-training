"""Bounded check of deferred probe finalization; synthetic and real stay distinct."""
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from time import monotonic

PROJECT=Path('/Users/baiyu/workspaces/githubs/ai-agent-training/projects/llm-gateway')
sys.path[:0]=[str(PROJECT/'src'),str(PROJECT/'tests'),str(PROJECT/'tests/live')]
from f10_support import Environment, CredentialHeaders, BOOTSTRAP
from postgres_support import PostgresServer, write_config, migrate
from test_real_providers import real_registry
from f4_cases import registry
from services.models import DEFAULT_CONFIG_DIR
from utils.json_codec import dumps

ROOT=Path(Path('/tmp/llmgw-f11-diagnostic-r2-path').read_text().strip())/'probe-finalization'
ROOT.mkdir(exist_ok=False)
CONTROL='''
from pathlib import Path
from main import create_app as build
from settings import Settings
from providers.mock import MockProvider
ROOT=Path(__file__).parent
def create_app():
    return build(settings=Settings(env='test',_env_file=None),config_dir=ROOT/'config',provider=MockProvider(delay=11))
'''

async def run(pg,backend):
    path=ROOT/backend;path.mkdir();name=pg.create_database();env=Environment(pg,name,path,backend=backend)
    try:
        write_config(env.config,pg,name,registry() if backend=='mock' else real_registry())
        if backend=='real':
            (env.config/'credentials.yaml').symlink_to(DEFAULT_CONFIG_DIR/'credentials.yaml')
            (env.config/'prices.yaml').symlink_to(DEFAULT_CONFIG_DIR/'prices.yaml')
        (path/'f10_bootstrap.py').write_text(CONTROL if backend=='mock' else BOOTSTRAP)
        await asyncio.to_thread(migrate,env.config)
        for agent in ('a','b'):
            await env.cli('create-agent',agent,'probe-finalization '+agent)
            headers=CredentialHeaders(Authorization='Bearer '+await env.cli('issue',agent))
            if agent=='a':env.headers=headers
            else:env.other_headers=headers
            await env.cli('deposit',agent,'10000','--operation-id','initial-'+agent)
        await env.start()
        models=['general-primary'] if backend=='mock' else ['general-primary','general-backup']
        for model in models:
            start=monotonic();response=await env.client.post('/v1/models/'+model+'/health');rid=response.headers['x-request-id']
            assert response.status_code in (200,503,504)
            observations=[]
            async with asyncio.timeout(5):
                while True:
                    trace=(await env.client.get('/v1/traces/'+rid)).json()['data']
                    observations.append(dict(elapsed_ms=(monotonic()-start)*1000,status=trace['status'],error_code=trace['error_code']))
                    if trace['status'] in ('completed','failed'):break
                    await asyncio.sleep(.02)
            def sql():
                with pg.connect(name) as db:
                    return [list(x) for x in db.execute('SELECT r.status,r.error_code,a.status,a.error_code,b.state,b.agent_charge,b.supplier_cost FROM tb_llm_request r JOIN tb_llm_attempt a ON a.request_pk=r.id JOIN tb_billing_attempt b ON b.request_pk=r.id AND b.attempt_no=a.attempt_no WHERE r.request_id=%s',(rid,)).fetchall()]
            saved=await asyncio.to_thread(sql)
            assert len(saved)==1 and saved[0][0]==saved[0][2]==trace['status']
            assert saved[0][1]==saved[0][3]==trace['error_code'] and saved[0][4]!='reserved'
            await env.assert_balances()
            if backend=='mock':
                assert response.status_code==504 and trace['error_code']=='provider_timeout'
                assert observations[-1]['elapsed_ms']<12500
            result=dict(backend=backend,model=model,request_id=rid,http_status=response.status_code,response=response.json(),
                        observations=observations,trace=trace,sql_rows=saved,balances_verified=True,
                        source='controlled Mock delay=11' if backend=='mock' else 'actual Provider; no scripted failure')
            (path/(model+'.json')).write_text(dumps(result))
            print(json.dumps(dict(backend=backend,model=model,http_status=response.status_code,status=trace['status'],code=trace['error_code'],initial_status=observations[0]['status'],elapsed_ms=observations[-1]['elapsed_ms'])),flush=True)
    finally:
        await env.stop();await asyncio.to_thread(pg.drop_database,name)

async def main():
    pg=await asyncio.to_thread(lambda:PostgresServer().start())
    try:
        await run(pg,'mock')
        await run(pg,'real')
    finally:await asyncio.to_thread(pg.close)

if __name__=='__main__':asyncio.run(main())
