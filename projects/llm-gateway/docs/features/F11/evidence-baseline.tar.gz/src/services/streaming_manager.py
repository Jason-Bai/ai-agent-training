"""Application-owned generation; HTTP subscribers never own the Provider task."""
import asyncio
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from time import monotonic

from contracts import Message
from constants import STREAM_CLEANUP_TIMEOUT_SECONDS, DATABASE_SHUTDOWN_GRACE_SECONDS
from errors import GatewayError
from persistence.database import StorageUnavailable
from persistence.store import TERMINAL, request_values
from services.trace import log_storage_failure
from services.streaming import PreparedStream, StreamingExecution, StreamFailure
from utils.json_codec import loads


@dataclass
class Cancellation:
    ready: asyncio.Future
    row: dict
    phase: str = 'new'
    last_logged_stage: str | None = None
    task: asyncio.Task | None = None
    trace: object = None
    attempt: object = None
    generation: asyncio.Task | None = None
    stop_sent: bool = False
    error_code: str | None = None


class StreamingManager:
    def __init__(self, storage, traces, registry, token_budget, providers, defer, active, *, awaiting_persistence):
        self.storage, self.traces, self.registry = storage, traces, registry
        self.token_budget, self.providers, self.defer = token_budget, providers, defer
        self.active = active
        self.awaiting_persistence = awaiting_persistence
        self.executions = {}
        self.tasks = {}
        self.claims = {}
        self.orphans = set()
        self.closing = False
        self.subscriptions = set()
        self.cancellations = {}
        self.cleanup_tasks = set()

    @asynccontextmanager
    async def _claim_lock(self, request_id):
        lock, users = self.claims.get(request_id, (asyncio.Lock(), 0))
        self.claims[request_id] = (lock, users + 1)
        try:
            async with lock:
                yield
        finally:
            _, users = self.claims[request_id]
            if users == 1:
                del self.claims[request_id]
            else:
                self.claims[request_id] = (lock, users - 1)

    async def _read_stream(self, request_id):
        try:
            return await self.storage.get_stream(request_id)
        except StorageUnavailable:
            log_storage_failure(request_id, 'get_stream')
            raise

    async def subscribe(self, request_id, after_seq):
        async with self._claim_lock(request_id):
            row = await self._read_stream(request_id)
            if row is None:
                raise GatewayError('not_found', '流式请求不存在', 404)
            if after_seq > row['last_event_seq']:
                raise GatewayError('invalid_event_cursor', '事件游标超过当前最后序号', 400)
            if row['status'] in TERMINAL:
                return row, None
            if self.closing:
                raise GatewayError('execution_interrupted', '服务正在停止', 503)
            if row['status'] == 'pending':
                started = monotonic()
                loop_start = asyncio.get_running_loop().time()
                timestamp = datetime.now(timezone.utc)
                timeout = row['timeout_seconds']
                deadline = loop_start + timeout
                # Until commit has been acknowledged, no task may call Provider.
                try:
                    claimed = await self.storage.claim_stream(request_id, timestamp,
                        timestamp + timedelta(seconds=timeout), deadline=deadline)
                except BaseException as exc:
                    if isinstance(exc, StorageUnavailable):
                        log_storage_failure(request_id, 'claim_stream')
                    self.orphans.add(request_id)
                    raise
                if claimed:
                    trace = self.traces.start_request(request_id, operation='streaming')
                    for field in request_values(trace):
                        setattr(trace, field, row[field])
                    trace.status, trace.error_code = 'running', None
                    trace._admitted = True
                    trace.stream_started_at = started
                    self.active.add(request_id)
                    coroutine = self._generate(row, trace, deadline)
                    try:
                        task = asyncio.create_task(coroutine)
                        self.tasks[request_id] = task
                        self.orphans.discard(request_id)
                        task.add_done_callback(lambda done: self._task_done(request_id, trace, done))
                    except BaseException:
                        coroutine.close()
                        self.active.discard(request_id)
                        self.orphans.add(request_id)
                        raise
                    # Registration precedes any suspension or visibility to another GET.
                    row = dict(row, status='running', started_at=timestamp,
                               deadline_at=timestamp + timedelta(seconds=timeout))
                else:
                    row = await self._read_stream(request_id)
            if (row['status'] in {'running', 'canceling'} and request_id not in self.tasks
                    and request_id not in self.cancellations
                    and not self.awaiting_persistence(request_id)):
                self.orphans.add(request_id)
                await self.storage.reconcile(request_id)
                self.orphans.discard(request_id)
                row = await self._read_stream(request_id)
            trace = self.traces.requests.get(request_id) if request_id in self.tasks else None
            if trace is None:
                return row, None

            def first_text(sent_at):
                if trace.first_text_sent_at is None:
                    trace.first_text_sent_at = sent_at
                    # The producer's final defer captures the same object. If it
                    # already stopped, queue only persisted-terminal diagnostics.
                    if request_id not in self.active:
                        self.defer(trace, next((a for a in reversed(self.traces.attempts)
                                               if a.request_id == request_id), None))
            return row, first_text

    async def cancel(self, request_id):
        async with self._claim_lock(request_id):
            row = await self._read_stream(request_id)
            if row is None:
                raise GatewayError('not_found', '流式请求不存在', 404)
            if row['status'] in TERMINAL:
                return row['status']
            if self.closing:
                raise GatewayError('execution_interrupted', '服务正在停止', 503)
            operation = self.cancellations.get(request_id)
            if operation is None:
                ready = asyncio.get_running_loop().create_future()
                # A disconnected HTTP caller must not leave an unobserved error.
                ready.add_done_callback(lambda value: value.exception() if not value.cancelled() else None)
                operation = Cancellation(ready, row)
                self.cancellations[request_id] = operation
                self._start_cancel(request_id, operation)
            if row['status'] == 'canceling':
                return 'canceling'
        return await asyncio.shield(operation.ready)

    def _start_cancel(self, request_id, operation):
        coroutine = self._cancel_operation(request_id, operation)
        try:
            operation.task = asyncio.create_task(coroutine)
        except Exception:
            coroutine.close()
            if not operation.ready.done():
                operation.ready.set_exception(GatewayError('internal_error', '服务内部错误', 500))
            return
        operation.task.add_done_callback(lambda task: task.exception() if not task.cancelled() else None)

    async def _cancel_operation(self, request_id, operation):
        try:
            async with self._claim_lock(request_id):
                if operation.phase in {'new', 'uncertain'}:
                    stage = 'accept_cancel' if operation.phase == 'new' else 'get_stream'
                    if operation.phase == 'new':
                        # Keep reconciliation responsibility even if commit ACK is lost.
                        operation.phase = 'uncertain'
                        status = await self.storage.accept_cancel(request_id)
                    else:
                        row = await self.storage.get_stream(request_id)
                        status = row['status'] if row is not None else None
                    if status is None:
                        raise GatewayError('not_found', '流式请求不存在', 404)
                    if status != 'canceling':
                        if not operation.ready.done():
                            operation.ready.set_result(status)
                        self.cancellations.pop(request_id, None)
                        return
                    trace = self.traces.requests.get(request_id)
                    if trace is None or getattr(trace, '_stream_creation', False):
                        trace = self.traces.start_request(request_id, operation='streaming')
                        for field in request_values(trace):
                            setattr(trace, field, operation.row[field])
                    trace.status, trace.error_code = 'canceling', None
                    trace._cancel_requested = True
                    trace._admitted = True
                    if operation.row['timing_snapshot'] and not hasattr(trace, '_skipped_candidates'):
                        trace._skipped_candidates = loads(operation.row['timing_snapshot']).get('skipped_candidates')
                    operation.trace = trace
                    operation.generation = self.tasks.get(request_id)
                    operation.phase = 'accepted'
                    execution = self.executions.get(request_id)
                    if execution is not None:
                        execution.cancel_requested = True
                    if not operation.ready.done():
                        operation.ready.set_result('canceling')
            if operation.phase == 'accepted':
                generation = operation.generation
                if generation is not None and not generation.done():
                    if not operation.stop_sent:
                        operation.stop_sent = True
                        generation.cancel()
                    done, _ = await asyncio.wait({generation}, timeout=STREAM_CLEANUP_TIMEOUT_SECONDS + DATABASE_SHUTDOWN_GRACE_SECONDS)
                    if not done:
                        operation.trace.cleanup_error_code = 'stream_cleanup_timeout'
                trace = operation.trace
                operation.attempt = next((a for a in reversed(self.traces.attempts)
                                          if a.request_id == request_id), None)
                operation.error_code = 'cancel_cleanup_failed' if trace.cleanup_error_code else None
                operation.phase = 'stopped'
            stage = 'finish_cancel'
            status = await self.storage.finish_cancel(operation.trace, operation.attempt,
                                                     error_code=operation.error_code)
            if status not in TERMINAL:
                raise RuntimeError('Cancellation did not reach terminal state')
            trace = operation.trace
            trace.status, trace.error_code = status, operation.error_code if status == 'failed' else None
            trace._persisted_terminal = True
            if operation.attempt is not None and operation.attempt.status in {'running', 'canceling'}:
                operation.attempt.status, operation.attempt.error_code = status, trace.error_code
            self.defer(trace, operation.attempt)
            self.cancellations.pop(request_id, None)
        except StorageUnavailable as exc:
            if operation.last_logged_stage != stage:
                log_storage_failure(request_id, stage, operation.attempt)
                operation.last_logged_stage = stage
            if not operation.ready.done():
                operation.ready.set_exception(exc)
        except GatewayError as exc:
            if not operation.ready.done():
                operation.ready.set_exception(exc)
            self.cancellations.pop(request_id, None)
        except Exception:
            if not operation.ready.done():
                operation.ready.set_exception(GatewayError('internal_error', '服务内部错误', 500))
            logging.getLogger(__name__).error('取消操作待恢复 request_id=%s', request_id)

    def _restore(self, row, trace):
        snapshot = loads(row['input_snapshot'])
        model = self.registry.models.get(row['requested_model'])
        from services.models import ModelConfig
        # F6 snapshots predate fallback_models; validate defaults before comparing
        # while still rejecting any actual candidate or budget configuration change.
        saved_model = ModelConfig.model_validate(snapshot['model'])
        if model is None or model != saved_model:
            raise ValueError('changed model')
        definition = self.registry.providers[model.provider]
        if definition.model_dump() != snapshot['provider']:
            raise ValueError('changed provider')
        if self.token_budget.counter_for(model).version != row['counter_version']:
            raise ValueError('changed counter')
        from services.models import RecoveryPolicy
        policy = RecoveryPolicy.model_validate(snapshot.get('recovery', {'max_attempts': 1, 'max_attempts_per_model': 1}))
        if 'recovery' in snapshot and policy != self.registry.recovery:
            raise ValueError('changed recovery')
        candidates = []
        initial = snapshot.get('initial_output_tokens', snapshot['max_output_tokens'])
        for entry in snapshot.get('candidates', []):
            candidate = self.registry.get(entry['name'])
            provider = self.registry.providers[candidate.provider]
            if (candidate.model_dump(mode='json') != entry['model'] or provider.model_dump() != entry['provider']
                    or self.token_budget.counter_for(candidate).version != entry['counter_version']):
                raise ValueError('changed candidate')
            candidates.append((PreparedStream(entry['name'], candidate, provider,
                [Message.model_validate(value) for value in snapshot['messages']], initial, snapshot['timeout_seconds']),
                self.providers[candidate.provider]))
        prepared = PreparedStream(row['requested_model'], model, definition,
            [Message.model_validate(value) for value in snapshot['messages']],
            initial, snapshot['timeout_seconds'])
        execution = StreamingExecution(prepared, self.providers[model.provider], trace, self.traces,
                                       storage=self.storage, defer=self.defer, snapshot=snapshot,
                                       recovery_policy=policy, candidates=candidates or None,
                                       authorized_output=snapshot['max_output_tokens'])
        execution.provider_admission = lambda start: self._admit_provider(trace.request_id, execution, start)
        return execution

    async def _admit_provider(self, request_id, execution, start):
        # Same boundary as cancel acceptance, including its uncertain ACK.
        # A plain status check outside this lock leaves check/start racing.
        async with self._claim_lock(request_id):
            row = await self.storage.get_stream(request_id)
            if row is not None and row['status'] == 'canceling':
                execution.cancel_requested = True
                execution.trace._cancel_requested = True
                return
            if row is None or row['status'] != 'running':
                raise StreamFailure('execution_interrupted')
            if not execution.cancel_requested:
                await start()

    async def _generate(self, row, trace, deadline):
        request_id = trace.request_id
        try:
            try:
                execution = self._restore(row, trace)
            except (ValueError, KeyError, TypeError, GatewayError):
                trace.error_code = 'execution_configuration_changed'
                trace.status = await self.storage.finish(trace, error_code=trace.error_code,
                    event=('response.failed', {'request_id': request_id, 'code': trace.error_code,
                                              'message': '执行配置已变更'}), deadline=deadline)
                trace._persisted_terminal = True
                return
            self.executions[request_id] = execution
            execution.deadline = deadline
            execution.prepared_storage = True
            trace._admitted = True
            await execution.run_background()
        except asyncio.CancelledError:
            if not getattr(trace, '_persisted_terminal', False) and not getattr(trace, '_cancel_requested', False):
                trace.error_code = 'execution_interrupted'
        except StorageUnavailable:
            if not getattr(trace, '_persisted_terminal', False):
                trace.error_code = 'storage_unavailable'
        except Exception:
            if not getattr(trace, '_persisted_terminal', False):
                trace.error_code = 'internal_error'
        finally:
            execution = self.executions.pop(request_id, None)
            if execution is not None:
                for task in execution.cleanup_tasks:
                    if not task.done():
                        self.cleanup_tasks.add(task)
                        task.add_done_callback(self.cleanup_tasks.discard)
            self.tasks.pop(request_id, None)
            self.active.discard(request_id)
            if not getattr(trace, '_cancel_requested', False):
                self.defer(trace, next((a for a in reversed(self.traces.attempts)
                                       if a.request_id == request_id), None))

    def _task_done(self, request_id, trace, task):
        if not task.cancelled():
            task.exception()
        if self.tasks.get(request_id) is task:
            self.tasks.pop(request_id)
            self.active.discard(request_id)
            if not getattr(trace, '_cancel_requested', False):
                trace.error_code = trace.error_code or 'internal_error'
                self.defer(trace)

    async def reconcile(self):
        for request_id, operation in list(self.cancellations.items()):
            if not self.closing and (operation.task is None or operation.task.done()):
                self._start_cancel(request_id, operation)
        for request_id in list(self.orphans):
            # A pending retry may have committed while its task registration
            # is still in flight. Recovery shares the same ownership lock.
            async with self._claim_lock(request_id):
                if (request_id not in self.active and request_id not in self.cancellations
                        and not self.awaiting_persistence(request_id)):
                    await self.storage.reconcile(request_id)
                    self.orphans.discard(request_id)

    async def close(self):
        self.closing = True
        subscribers = list(self.subscriptions)
        for task in subscribers:
            task.cancel()
        if subscribers:
            await asyncio.wait(subscribers, timeout=STREAM_CLEANUP_TIMEOUT_SECONDS)
        tasks = list(self.tasks.values())
        for execution in self.executions.values():
            execution.stop_error = 'execution_interrupted'
        for task in tasks:
            task.cancel()
        tasks += [op.task for op in self.cancellations.values() if op.task is not None]
        tasks += list(self.cleanup_tasks)
        if tasks:
            # Each executor owns its one-second upstream cleanup. This outer
            # allowance also covers a task canceled before its first bytecode.
            done, pending = await asyncio.wait(tasks, timeout=STREAM_CLEANUP_TIMEOUT_SECONDS + DATABASE_SHUTDOWN_GRACE_SECONDS)
            for task in done:
                if not task.cancelled():
                    task.exception()
            if pending:
                for task in pending:
                    task.cancel()
        # A task canceled before _generate began cannot run its finally.
        for request_id in list(self.tasks):
            if self.tasks[request_id].done():
                self.tasks.pop(request_id)
                self.active.discard(request_id)
                self.orphans.add(request_id)
