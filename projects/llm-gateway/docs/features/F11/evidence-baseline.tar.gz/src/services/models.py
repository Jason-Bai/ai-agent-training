from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Literal, Mapping
from urllib.parse import urlsplit

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from starlette import status as http_status

from errors import GatewayError


DEFAULT_CONFIG_DIR = Path(__file__).resolve().parents[2] / 'config'


class ConfigurationError(ValueError):
    """Only safe field/file identifiers may appear in configuration diagnostics."""


class Definition(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True, extra='forbid', hide_input_in_errors=True)

    @field_validator('*')
    @classmethod
    def nonblank_strings(cls, value):
        if isinstance(value, str) and not value.strip():
            raise ValueError('配置文本不能为空')
        return value


class RecoveryPolicy(Definition):
    max_attempts: int = Field(default=3, ge=1, le=3)
    max_attempts_per_model: int = Field(default=2, ge=1, le=2)
    base_delay_seconds: float = Field(default=0.1, ge=0, allow_inf_nan=False)
    max_delay_seconds: float = Field(default=1.0, ge=0, allow_inf_nan=False)

    @model_validator(mode='after')
    def limits(self):
        if self.max_attempts_per_model > self.max_attempts:
            raise ValueError('单模型次数超过总次数')
        if self.base_delay_seconds > self.max_delay_seconds:
            raise ValueError('基础退避超过最大退避')
        return self


class ProviderConfig(Definition):
    adapter: Literal['mock', 'deepseek', 'openai_compatible']
    api_protocol: Literal['chat_completions', 'responses']
    base_url: str | None = None
    credential_ref: str | None = None

    @model_validator(mode='after')
    def connection_definition(self):
        required_protocol = {'deepseek': 'chat_completions', 'openai_compatible': 'responses'}.get(self.adapter)
        if required_protocol is not None and self.api_protocol != required_protocol:
            raise ValueError('适配器与 API 协议不兼容')
        if self.adapter == 'mock':
            if self.base_url is not None or self.credential_ref is not None:
                raise ValueError('Mock 不需要连接和凭据配置')
        else:
            if not self.base_url or not self.credential_ref:
                raise ValueError('真实 Provider 需要地址和凭据引用')
            parsed = urlsplit(self.base_url)
            if parsed.scheme not in {'http', 'https'} or not parsed.netloc:
                raise ValueError('Provider 地址必须为 HTTP(S) 地址')
        return self


class ModelConfig(Definition):
    provider: str
    model_id: str
    thinking_mode: Literal['disabled'] = 'disabled'
    token_counter: str
    supports_streaming: bool
    structured_output_mode: Literal['none', 'json_object', 'json_schema']
    context_window_tokens: int = Field(gt=0)
    provider_max_output_tokens: int = Field(gt=0)
    default_output_tokens: int = Field(gt=0)
    max_output_tokens: int = Field(gt=0)
    safety_margin_tokens: int = Field(gt=0)
    default_timeout_seconds: int = Field(gt=0)
    max_timeout_seconds: int = Field(gt=0)
    fallback_models: tuple[str, ...] = Field(default=(), max_length=1)

    @field_validator('fallback_models', mode='before')
    @classmethod
    def freeze_fallbacks(cls, value):
        if not isinstance(value, (list, tuple)):
            raise ValueError('备用模型必须为列表')
        return tuple(value)

    @model_validator(mode='after')
    def budget_relationships(self):
        if not self.default_output_tokens <= self.max_output_tokens <= self.provider_max_output_tokens:
            raise ValueError('默认输出、平台输出和供应商输出上限关系不合法')
        if self.default_timeout_seconds > self.max_timeout_seconds:
            raise ValueError('默认超时超过平台上限')
        if self.default_output_tokens + self.safety_margin_tokens >= self.context_window_tokens:
            raise ValueError('上下文窗口没有为输入保留空间')
        return self


@dataclass(frozen=True)
class ModelRegistry:
    models: Mapping[str, ModelConfig]
    providers: Mapping[str, ProviderConfig]
    recovery: RecoveryPolicy = field(default_factory=RecoveryPolicy)

    def __post_init__(self):
        try:
            if not self.models or not self.providers:
                raise ValueError
            models = {name: model if isinstance(model, ModelConfig) else ModelConfig.model_validate(model)
                      for name, model in self.models.items()}
            providers = {name: provider if isinstance(provider, ProviderConfig) else ProviderConfig.model_validate(provider)
                         for name, provider in self.providers.items()}
            if any(not isinstance(name, str) or not name.strip() for name in [*models, *providers]):
                raise ValueError
            if any(model.provider not in providers for model in models.values()):
                raise ValueError
            recovery = (self.recovery if isinstance(self.recovery, RecoveryPolicy)
                        else RecoveryPolicy.model_validate(self.recovery))
            for name, model in models.items():
                if any(other not in models or other == name for other in model.fallback_models):
                    raise ValueError
            for name, model in models.items():
                visited = {name}
                current = model
                while current.fallback_models:
                    target = current.fallback_models[0]
                    if target in visited:
                        raise ValueError
                    visited.add(target)
                    current = models[target]
            modes = {'chat_completions': {'none', 'json_object'}, 'responses': {'none', 'json_schema'}}
            if any(model.structured_output_mode not in modes[providers[model.provider].api_protocol]
                   for model in models.values()):
                raise ValueError
        except (ValueError, TypeError, AttributeError):
            raise ConfigurationError('模型注册配置不合法：请检查字段、预算和 Provider 引用') from None
        object.__setattr__(self, 'models', MappingProxyType(models))
        object.__setattr__(self, 'providers', MappingProxyType(providers))
        object.__setattr__(self, 'recovery', recovery)

    def candidates(self, name: str) -> tuple[str, ...]:
        return (name, *self.get(name).fallback_models)

    def get(self, name: str) -> ModelConfig:
        try:
            return self.models[name]
        except KeyError:
            raise GatewayError('unknown_model', '逻辑模型未注册', http_status.HTTP_400_BAD_REQUEST) from None


class UniqueKeyLoader(yaml.SafeLoader):
    pass


def _unique_mapping(loader, node):
    pairs = loader.construct_pairs(node)
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('YAML 存在重复键')
        result[key] = value
    return result


UniqueKeyLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _unique_mapping)


def read_yaml(path: Path) -> dict:
    try:
        with path.open(encoding='utf-8') as stream:
            data = yaml.load(stream, Loader=UniqueKeyLoader)
        if not isinstance(data, dict):
            raise ValueError
        return data
    except (OSError, UnicodeError, yaml.YAMLError, ValueError, TypeError, RecursionError):
        raise ConfigurationError(f'{path.name} 无法读取或 YAML 结构不合法') from None


def load_registry(config_dir: Path = DEFAULT_CONFIG_DIR) -> ModelRegistry:
    data = read_yaml(config_dir / 'gateway.yaml')
    if not {'models', 'providers'} <= set(data) or set(data) - {'models', 'providers', 'database', 'recovery'}:
        raise ConfigurationError('gateway.yaml 必须包含 models、providers，可包含 database、recovery，不能包含其他顶层字段')
    return ModelRegistry(models=data['models'], providers=data['providers'], recovery=data.get('recovery', {}))
