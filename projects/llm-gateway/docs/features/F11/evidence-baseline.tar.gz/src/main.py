from contextlib import asynccontextmanager
import asyncio
import logging
from pathlib import Path
from typing import Mapping

from fastapi import FastAPI

from api.errors import register_error_handlers
from api.routes import router
from api.billing import router as billing_router
from api.identity import AgentIdentityMiddleware
from services.prices import PriceBook
from middleware.request_context import RequestContextMiddleware
from providers.base import Provider
from providers.factory import ProviderClients
from services.models import DEFAULT_CONFIG_DIR, ModelRegistry, load_registry
from services.prompts import DEFAULT_TEMPLATES, PromptRegistry
from services.token_budget import TokenBudget
from services.trace import TraceStore
from services.streaming_manager import StreamingManager
from settings import Settings, load_settings
from persistence.database import Database, StorageUnavailable, load_database_config
from persistence.store import Store
from services.models import ConfigurationError
from constants import DATABASE_RECONCILE_INTERVAL_SECONDS, DATABASE_SHUTDOWN_GRACE_SECONDS


def create_app(
    *, settings: Settings | None = None, provider: Provider | None = None,
    providers: Mapping[str, Provider] | None = None,
    prompt_registry: PromptRegistry | None = None, model_registry: ModelRegistry | None = None,
    token_budget: TokenBudget | None = None, config_dir: Path = DEFAULT_CONFIG_DIR,
    database: Database | None = None,
) -> FastAPI:
    settings = load_settings() if settings is None else settings
    prompt_registry = PromptRegistry(DEFAULT_TEMPLATES) if prompt_registry is None else prompt_registry
    model_registry = load_registry(config_dir) if model_registry is None else model_registry
    models = model_registry.models.values()
    token_budget = TokenBudget.from_models(models) if token_budget is None else token_budget
    token_budget.validate_models(models)
    clients = ProviderClients(model_registry, provider=provider, providers=providers, config_dir=config_dir)
    database = Database(load_database_config(config_dir), config_dir) if database is None else database
    storage = Store(database, PriceBook.load(config_dir))
    active = set()
    generations = set()
    pending = {}
    manager = None

    def defer(trace, attempt=None):
        existing = pending.get(trace.request_id)
        if existing is not None and getattr(trace, '_stream_creation', False) and not getattr(existing[0], '_stream_creation', False):
            return
        pending[trace.request_id] = (trace, attempt)

    def awaiting_persistence(request_id):
        entry = pending.get(request_id)
        return entry is not None and not getattr(entry[0], '_stream_creation', False)

    async def flush_pending():
        for request_id, entry in list(pending.items()):
            trace, attempt = entry
            if request_id in active or request_id in generations:
                continue
            if getattr(trace, '_cancel_requested', False) and not getattr(trace, '_persisted_terminal', False):
                continue
            try:
                if getattr(trace, '_stream_creation', False):
                    # An unacknowledged POST commit is not stopped generation.
                    # Preserve any valid request even if GET already started it.
                    row = await storage.get_stream(request_id)
                    if row is not None:
                        trace.status, trace.error_code = row['status'], row['error_code']
                        if pending.get(request_id) is entry:
                            pending.pop(request_id, None)
                        continue
                if not getattr(trace, '_persisted_terminal', False):
                    error = trace.error_code or 'storage_unavailable'
                    event = ('response.failed', {'request_id': request_id, 'code': error,
                             'message': '请求未能完成'}) if trace.operation == 'streaming' and getattr(trace, '_admitted', False) else None
                    status = await storage.finish(trace, attempt, error_code=error, event=event, reconciling=True)
                    trace.status = status
                    if attempt is not None and (attempt.status == 'running' or status == 'completed'):
                        attempt.status = status
                        if status == 'completed':
                            attempt.error_code = None
                    trace._persisted_terminal = True
                await storage.update_diagnostics(trace, attempt)
                if pending.get(request_id) is entry:
                    pending.pop(request_id, None)
            except StorageUnavailable:
                if asyncio.current_task().cancelling():
                    raise asyncio.CancelledError
            except Exception:
                logging.getLogger(__name__).error('持久化恢复失败 request_id=%s', request_id)

    async def reconcile_pending():
        while True:
            try:
                await manager.reconcile()
            except StorageUnavailable:
                pass
            await flush_pending()
            await asyncio.sleep(DATABASE_RECONCILE_INTERVAL_SECONDS)

    @asynccontextmanager
    async def lifespan(app):
        recovery = None
        try:
            try:
                await database.start()
                await storage.recover()
            except StorageUnavailable:
                raise ConfigurationError('数据库连接、结构版本或启动恢复检查失败') from None
            recovery = asyncio.create_task(reconcile_pending())
            async with clients.open() as instances:
                app.state.providers = instances
                manager.providers = instances
                try:
                    yield
                finally:
                    await manager.close()
        finally:
            if recovery is not None:
                recovery.cancel()
                await asyncio.gather(recovery, return_exceptions=True)
                try:
                    async with asyncio.timeout(DATABASE_SHUTDOWN_GRACE_SECONDS):
                        await manager.reconcile()
                        await flush_pending()
                except (TimeoutError, StorageUnavailable):
                    pass
            await database.close()

    app = FastAPI(title="LLM Gateway", redirect_slashes=False, lifespan=lifespan)
    traces = TraceStore()
    manager = StreamingManager(storage, traces, model_registry, token_budget, clients.instances, defer, generations,
                               awaiting_persistence=awaiting_persistence)
    app.state.streaming_manager = manager
    app.state.settings = settings
    app.state.providers = clients.instances
    app.state.prompt_registry = prompt_registry
    app.state.model_registry = model_registry
    app.state.token_budget = token_budget
    app.state.traces = traces
    app.state.storage = storage
    app.state.defer_persistence = defer
    register_error_handlers(app)
    app.include_router(router)
    app.include_router(billing_router)
    app.add_middleware(RequestContextMiddleware, traces=traces, storage=storage, active=active, defer=defer)
    app.add_middleware(AgentIdentityMiddleware, database=database)
    return app
