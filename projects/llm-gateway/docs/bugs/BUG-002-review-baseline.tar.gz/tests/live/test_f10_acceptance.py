"""An independent Agent client exercises the same real-process public contract."""
import asyncio
from decimal import Decimal
import json

import pytest

from f10_support import f10_environment, frames, payload


pytestmark = pytest.mark.live
MODELS = ['general-primary', 'general-backup']


def evidence(record_property, **values):
    for name, value in values.items():
        record_property(name, json.dumps(value, ensure_ascii=False) if isinstance(value, (dict,list)) else value)


async def committed(environment, rid):
    async with asyncio.timeout(12):
        while True:
            response = await environment.client.get('/v1/traces/'+rid)
            assert response.status_code == 200
            if response.json()['data']['status'] in {'completed','failed','canceled'}:
                return response.json()['data']
            await asyncio.sleep(.02)


async def request_state(environment, rid):
    def read():
        with environment.pg.connect(environment.name) as sql:
            row = sql.execute('SELECT id,status FROM tb_llm_request WHERE request_id=%s',(rid,)).fetchone()
            attempts = sql.execute('SELECT count(*) FROM tb_llm_attempt WHERE request_pk=%s',(row[0],)).fetchone()[0]
            bills = sql.execute('SELECT count(*) FROM tb_billing_attempt WHERE request_pk=%s',(row[0],)).fetchone()[0]
            events = sql.execute('SELECT count(*) FROM tb_llm_stream_event WHERE request_pk=%s',(row[0],)).fetchone()[0]
        return dict(status=row[1], attempts=attempts, bills=bills, events=events)
    return await asyncio.to_thread(read)


@pytest.mark.parametrize('model', MODELS)
@pytest.mark.parametrize('mode', ['text','structured','streaming'])
async def test_real_agent_success_and_cost(f10_environment, model, mode, record_property):
    env = f10_environment
    initial = await env.account_totals()
    assert Decimal(initial['deposited']) == Decimal('10000')
    result = await env.call(model,mode)
    assert result['status'] == 'completed', result['error_code']
    trace = await committed(env,result['request_id'])
    assert trace['requested_model'] == model
    assert trace['usage']['unknown_attempts'] == []
    verified = await env.verify(result['request_id'])
    assert verified['attempts'] == 1
    assert trace['attempts'][0]['api_protocol'] == ('chat_completions' if model=='general-primary' else 'responses')
    if mode == 'streaming':
        assert result['first_text_ms'] is not None
        deltas = [e[2]['delta'] for e in result['events'] if e[1]=='response.delta']
        assert deltas and 'A123' in ''.join(deltas) and '充电器' in ''.join(deltas)
    await env.assert_balances()
    evidence(record_property,model=model,mode=mode,request_id=result['request_id'],
             observation=verified,latency_ms=result['elapsed_ms'],first_text_ms=result['first_text_ms'])


@pytest.mark.parametrize('model', MODELS)
async def test_real_disconnect_resume_keeps_one_generation(f10_environment,model,record_property):
    env = f10_environment
    response = await env.client.post('/v1/llm/stream',json=payload(model,'streaming'))
    assert response.status_code==202
    rid = response.json()['data']['request_id']
    initial = await request_state(env,rid)
    assert initial == {'status':'pending','attempts':0,'bills':0,'events':0}
    url = f'/v1/llm/stream/{rid}/events'
    first = None
    async with env.client.stream('GET',url) as response:
        assert response.status_code==200
        async for event in frames(response):
            if event[1]=='response.delta':
                first=event
                break
    assert first is not None
    resumed=[]
    async with env.client.stream('GET',url,params={'after_seq':first[0]}) as response:
        assert response.status_code==200
        async for event in frames(response):
            if event[1]!='response.heartbeat': resumed.append(event)
    assert resumed and resumed[-1][1]=='response.completed'
    assert [event[0] for event in resumed]==list(range(first[0]+1,resumed[-1][0]+1))
    text=first[2]['delta']+''.join(event[2]['delta'] for event in resumed if event[1]=='response.delta')
    assert 'A123' in text and '充电器' in text
    await committed(env,rid)
    detail=(await env.client.get('/v1/billing/requests/'+rid)).json()['data']
    assert len(detail['attempts'])==1
    assert (await env.client.get(url,params={'after_seq':resumed[-1][0]})).status_code==204
    replay=(await env.client.get(url,params={'after_seq':first[0]})).text
    assert 'response.completed' in replay
    assert (await env.client.get('/v1/billing/requests/'+rid)).json()['data']==detail
    checked=await env.verify(rid)
    assert checked['attempts']==1
    await env.assert_balances()
    evidence(record_property,model=model,request_id=rid,first_seq=first[0],last_seq=resumed[-1][0],observation=checked)


async def cancel_until_terminal(env,rid):
    async with asyncio.timeout(12):
        while True:
            response=await env.client.post(f'/v1/llm/stream/{rid}/cancel')
            assert response.status_code in {200,202}
            status=response.json()['data']['status']
            if response.status_code==200:
                assert status in {'completed','failed','canceled'}
                return status
            assert status=='canceling'
            await asyncio.sleep(.02)


@pytest.mark.parametrize('model',MODELS)
async def test_real_cancel_pending_and_in_progress(f10_environment,model,record_property):
    env=f10_environment
    pending=(await env.client.post('/v1/llm/stream',json=payload(model,'streaming'))).json()['data']['request_id']
    assert await cancel_until_terminal(env,pending)=='canceled'
    assert (await request_state(env,pending))['attempts']==0
    await env.verify(pending)
    rid=(await env.client.post('/v1/llm/stream',json=payload(model,'streaming'))).json()['data']['request_id']
    received=[]
    async with env.client.stream('GET',f'/v1/llm/stream/{rid}/events') as response:
        assert response.status_code==200
        iterator=frames(response)
        async with asyncio.timeout(35):
            async for event in iterator:
                if event[1]!='response.heartbeat': received.append(event)
                if event[1]=='response.delta': break
            assert received and received[-1][1]=='response.delta'
            terminal=await cancel_until_terminal(env,rid)
            async for event in iterator:
                if event[1]!='response.heartbeat': received.append(event)
    assert received[-1][1]=='response.'+terminal
    before=(await env.client.get('/v1/billing/requests/'+rid)).json()['data']
    assert await cancel_until_terminal(env,rid)==terminal
    assert (await env.client.get('/v1/billing/requests/'+rid)).json()['data']==before
    checked=await env.verify(rid)
    await env.assert_balances()
    evidence(record_property,model=model,request_id=rid,pending_id=pending,terminal=terminal,observation=checked)


async def test_real_cli_rotation_ownership_restart_and_budget(f10_environment,record_property):
    env=f10_environment
    def counts():
        with env.pg.connect(env.name) as sql:
            return tuple(sql.execute('SELECT count(*) FROM '+table).fetchone()[0]
                         for table in ('tb_llm_request','tb_llm_attempt','tb_billing_attempt'))
    initial_counts=await asyncio.to_thread(counts)
    for authorization in (None,'Bearer invalid-test-token'):
        request=env.client.build_request('POST','/v1/llm',json=payload())
        request.headers.pop('Authorization',None)
        if authorization is not None: request.headers['Authorization']=authorization
        rejected=await env.client.send(request)
        assert rejected.status_code==401 and rejected.json()['data'] is None
    assert await asyncio.to_thread(counts)==initial_counts
    created=await env.client.post('/v1/llm/stream',json=payload())
    rid=created.json()['data']['request_id']
    original=await request_state(env,rid)
    for method,path in [('get',f'/v1/traces/{rid}'),('get',f'/v1/billing/requests/{rid}'),
                        ('get',f'/v1/llm/stream/{rid}/events'),('post',f'/v1/llm/stream/{rid}/cancel'),
                        ('get',f'/v1/llm/stream/{rid}/events%0A'),('post',f'/v1/llm/stream/{rid}/cancel%0A')]:
        assert (await getattr(env.client,method)(path,headers=env.other_headers)).status_code==404
    assert await request_state(env,rid)==original
    old=env.headers['Authorization']
    public=old.split(' ',1)[1].split('.',1)[0]
    new=await env.cli('rotate','a',public)
    assert (await env.client.get('/v1/traces/'+rid,headers={'Authorization':old})).status_code==401
    env.headers={'Authorization':'Bearer '+new}
    env.client.headers.update(env.headers)
    assert (await env.client.get('/v1/traces/'+rid)).status_code==200
    await env.restart()
    assert (await request_state(env,rid))==original
    assert (await env.client.get('/v1/traces/'+rid)).status_code==200
    await cancel_until_terminal(env,rid)
    await env.verify(rid)
    await env.cli('create-agent','poor','zero budget')
    poor=await env.cli('issue','poor')
    headers={'Authorization':'Bearer '+poor}
    rejected=[]
    for path in ['/v1/llm','/v1/models/general-primary/health']:
        response=await env.client.post(path,json=payload() if path=='/v1/llm' else None,headers=headers)
        assert response.status_code==402 and response.json()['code']=='insufficient_budget'
        rejected.append(response.headers['x-request-id'])
    pending=(await env.client.post('/v1/llm/stream',json=payload(),headers=headers)).json()['data']['request_id']
    response=await env.client.get(f'/v1/llm/stream/{pending}/events',headers=headers)
    assert 'insufficient_budget' in response.text
    rejected.append(pending)
    for rejected_id in rejected:
        assert (await request_state(env,rejected_id))['attempts']==0
    totals=await env.account_totals(headers)
    assert Decimal(totals['charged'])==Decimal(totals['reserved'])==0
    await env.assert_balances()
    evidence(record_property,request_id=rid,zero_budget_requests=rejected,rotation_verified=True,restart_verified=True)
