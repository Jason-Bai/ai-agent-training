# LLM Gateway（1.6 学习项目）

> **1.6 已收尾（2026-11-03）**：当前限定内部Agent、本机或隔离网络、单实例单worker。完成范围、最终证据、Mock/真实Provider定位及非阻断遗留统一见[1.6收尾记录](docs/1.6-closeout.md)。

> **1.7交付顺序已确认，当前为文档阶段**：[BUG-002测试隔离 → 并发治理 → 模型管理与路由](docs/1.7-plan.md)。后两项分别作为独立Feature，逐项确认完整设计与测试后实施；当前首先确认BUG-002测试方案，不提前实现后续功能。

> 状态：F1/F1-O1/F2/F3 已验收；F4 已验收通过：离线836、Python3.12关键233、真实六例通过，Claude Code第1轮APPROVED。F5 已验收：最终离线1099、Python3.12关键235、最新真实两例通过，原生Claude Code第2轮APPROVED；F6验收通过，F7验收通过，F8 已验收通过（[代码导读](docs/features/F8/implementation-summary.md)），F9 已验收（最终2010通过含真实16，[修复及独审](docs/bugs/F9-B1.md)），F10 已验收（全量2039通过、首轮独审APPROVED，[总验收报告](docs/features/F10/acceptance-report.md)）。默认配置仍使用 Mock。

[F1-O1 独立优化](docs/features/F1/optimizations/O1/design.md)已实现 Middleware 抽取、目录命名、环境配置与应用工厂启动；115 个测试与 Claude Code 独立审查均通过，验收通过。[本项测试与证据](docs/features/F1/optimizations/O1/test-plan.md)独立维护；原 F1 记录保留历史快照。

[F2 受控 Prompt](docs/features/F2/design.md)已实现：三份模板、User 变量、静态 Few-shot 与消息指纹。本地 223 个测试及 Claude Code 第 1 轮独立审查通过；逐例结果见 [F2 测试方案](docs/features/F2/test-plan.md)。

[F3 设计方案](docs/features/F3/design.md)与[测试方案及证据](docs/features/F3/test-plan.md)已获实施授权。当前支持 YAML/独立凭据、统一 Mock/真实适配、Token/超时预算与主动探测；真实调用与代码审查的实际状态以测试方案为准。

本项目以 [1.6 LLM Gateway 课程材料](../../docs/网页版完整内容/1.6-LLMGateway.md) 为主线，递增构建供内部 Agent 调用的模型入口。Gateway 管理**一次模型调用**；Agent/Harness 决定任务目标、工具使用、业务判断和调用结果如何进入下一步。模型生成候选结果，业务动作仍由业务程序授权。

F4 阅读入口：[代码实现导读](docs/features/F4/implementation-summary.md)、[设计方案](docs/features/F4/design.md)、[测试与独立审查](docs/features/F4/test-plan.md)、[response_schema 完整规则](docs/response-schema.md)。已支持统一Schema请求、Chat/Responses约束生成、完整预算和严格JSON/Schema验收；HTTP到Provider再到parsed保持精确十进制，业务事实与权限仍由Agent负责。

[F4-O1 平台常量与 JSON 工具整理](docs/features/F4/optimizations/O1/design.md)已验收：离线878通过/6 live跳过、Python3.12关键268通过，原生Claude Code第2轮APPROVED；首轮目录树/状态发现已修正。[代码导读](docs/features/F4/optimizations/O1/implementation-summary.md)、[测试与审查处置](docs/features/F4/optimizations/O1/test-plan.md)独立记录，原 F4 验收历史保留。

原 F5 基线阅读入口：[代码实现导读](docs/features/F5/implementation-summary.md)、[Streaming 设计](docs/features/F5/design.md)、[逐例测试与执行记录](docs/features/F5/test-plan.md)。已实现真增量 SSE、总期限/15秒空闲心跳、统一 Provider 事件、背压、断连清理及内部 TTFT/Generation 指标；已通过功能验证及原生Claude Code第2轮独审，最终证据见测试方案3.10。

[F5-O1 统一持久化基础](docs/features/F5/optimizations/O1/design.md)的设计及[测试方案](docs/features/F5/optimizations/O1/test-plan.md)已分别确认，已实现并验收通过：串行全量1228通过/14 live跳过、Python3.12关键312通过，原生Claude Code第2轮APPROVED，无P0–P2；代码入口见[实现导读](docs/features/F5/optimizations/O1/implementation-summary.md)。普通及流式已接 PostgreSQL。O2两阶段调用与续传已验收：完整1330通过/16 live跳过，修正相关严格41通过，真实两条通过；累计第2轮全新Agent独审APPROVED、无P0–P3。F6主动取消已完成实现与验证，验收通过。默认绑定已按用户最新要求切回 Mock，已有真实 Provider Key 保留。

[F5-O2 代码导读](docs/features/F5/optimizations/O2/implementation-summary.md)：POST创建、GET首次启动、PG分页续传、后台生成与订阅隔离；[验收通过](docs/features/F5/optimizations/O2/test-plan.md#39-最终验收)，完整1330项/修正相关严格41项通过。

[F6 流式取消设计](docs/features/F6/design.md)及[测试与验收](docs/features/F6/test-plan.md#38-最终验收)已验收通过：调用方通过 `POST /v1/llm/stream/{request_id}/cancel` 发起及轮询取消；pending/running 均先进入 canceling，Gateway 独立停止、清理并保存终态。处理中202/canceling，终态200并返回canceled/failed/completed；不依赖SSE确认取消结果。

F6本地更新需要先启动项目PostgreSQL，再在项目根显式执行 `uv run alembic upgrade head` 升级至当前版本（F6 引入的迁移为 `f6_001`），然后启动Gateway；旧版本库会被启动检查拒绝，不会自动迁移。取消调用示例：

```bash
curl -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" -sS -X POST "http://127.0.0.1:8000/v1/llm/stream/${REQUEST_ID}/cancel"
```

REQUEST_ID取创建接口返回值。首次取消后可间隔500ms重复同一POST；202/canceling继续等待，200时读取canceled/failed/completed并停止轮询。接口错误不当作生成终态；无需请求体，也不用传Provider或上游协议。已提交历史事件仍可按after_seq读取。


## 已确定的范围

- 首版只在本机或隔离开发网络运行，单 Gateway 实例、单 worker；多个内部 Agent 可以同时调用。对外开放及多实例协调留到 1.7 复议。
- F3 已实现两种接入：主侧 `DeepSeekProvider`，备用侧按 OpenAI 角色使用 `OpenAICompatibleProvider`；当前按已确认的 `deepseek-flash` 验证。实际元信息、文档能力和真实测试的证据边界见 [F3 设计](docs/features/F3/design.md)。
- Prompt 选择必填，System 规则来自受控模板；调用方消息只允许 `user`、`assistant`。F1 的最小入口先只接收一条 `user` 消息。
- 非流式 API 的成功和错误 JSON 统一为 `success`、`code`、`data`、`message` 四个顶层字段；普通调用的 `request_id` 只在 `X-Request-ID` 响应头；流式创建另在 data 返回ID。已开始的 SSE 使用事件表达生成结果。
- F4 已接入普通调用的 `response_schema`，使用 `context_answer@1.2.0`；完整支持边界见规则文档。F5 流式请求不声明 `response_schema`，提供时即使为 null 也在调用 Provider 前拒绝。
- 流式对外事件统一为 `response.*`；F5-O2先POST创建、再GET订阅并按SSE id续传；F6已实现pending/running请求主动取消，当前验收通过。
- F5-O1 已接入普通及流式请求/Attempt、完整执行输入及流式业务事件的 PostgreSQL 持久化，由 Compose 管理；API Key 不落库，未知 Usage 不记实测 0，暂不实现数据清理。主动探测在 O1 时仅使用内存，F8 将其接入同一组表。原 SQLite 规划由此替换；O1 验收状态以本项测试方案为准。
- F9 按内部 Agent 的可用余额准入，并对每次 Provider 尝试预留、结算和对账。完整规则见 [F9 设计](docs/features/F9/design.md)。

## 入口与组件

| 边界 | 职责 | 缺少时的后果 |
| --- | --- | --- |
| FastAPI + Contract | 统一 HTTP/SSE 输入、输出和错误 | 上层依赖供应商格式；入口错误可能仍调用模型 |
| Prompt 组件 | 按名称、版本和受控变量装配规则 | 无法复现调用规则；调用方可能覆盖 System 规则 |
| 模型配置组件 | 逻辑模型、白名单、连接与能力检查 | 不能判断主备模型能否承接同一请求 |
| Provider 适配器 | 转换供应商请求，归一化响应、事件和 Usage | SDK 差异渗入 Agent 与执行主链 |
| GatewayService | 编排调用、校验、恢复与留痕 | 多个入口各自实现不一致的流程 |
| 结果校验组件 | 区分 JSON 语法、Schema 和业务校验边界 | 错误候选结果被包装成成功 |
| 恢复策略组件 | 错误分类、预算、重试和能力匹配的 fallback | 非可恢复错误乱重试，流式内容可能重复 |
| Trace / 持久化组件 | PostgreSQL 保存普通、流式和主动探测的请求与 Attempt；按 request_id 查询元数据，流式事件单独用于续传 | 故障、模型切换和用量来源无法还原，事件无法补读 |
| 用量与计费组件 | 基于实际 Usage 和价格规则核算费用，关联调用记录结算与对账 | Token 用量无法转成可核对的费用，本地预算可能被误当作实测收费依据 |

完整流程图、组件关系与单实例边界见 [架构说明](docs/architecture.md)。接口草案见 [契约说明](docs/contracts.md)。

## 本地运行与验证

在本项目目录运行。首次先准备本地数据库密码，复制时不要覆盖已有文件，编辑文件替换占位内容，不在聊天中发送密码：

```bash
cp -n config/postgres.password.example config/postgres.password
```

密码供 PostgreSQL 容器与 Gateway/Alembic 共用，不进入版本管理或 `.env`。 数据库默认本机端口 15432，库和用户名均为 llm_gateway，参数见 gateway.yaml 的 database 段。正常停止 Compose 保留数据卷，应用不自动迁移或降级。然后建立数据库、显式迁移、启动单 worker 应用：

```bash
uv sync --locked
docker compose up -d --wait
uv run alembic upgrade head
uv run uvicorn --app-dir src main:create_app --factory --host 127.0.0.1 --port 8000 --workers 1 --timeout-graceful-shutdown 5
```

可选从 [.env.example](.env.example) 复制 `.env`，已有文件请保留；F3 仅保留运行参数。旧文件若含 `LLM_GATEWAY_PROVIDER`，请由维护者移除该旧键并迁移为 YAML，启动会明确拒绝旧配置，不自动覆盖文件。默认 YAML 为两条 Mock，具备已随项目提供的计数资源即可运行：

```dotenv
ENV=development
```

`ENV` 允许 `development`、`test`、`production`；Provider 由 `config/gateway.yaml` 中模型的 provider 引用选择，ENV 不改变这个绑定。正常加载顺序为进程环境变量 → 项目根 `.env` → 默认值；非法值在启动时拒绝，`.env.example` 不作为运行配置读取。文件路径不受工作目录影响，修改配置后重启才生效。`production` 仅为标识，仍受首版本机/隔离网络、单 worker 边界约束。

模型与 Provider 使用 [config/gateway.yaml](config/gateway.yaml)，仅加载该文件，不自动叠加多环境 YAML。默认 `general-primary`、`general-backup` 均绑定 Mock，可离线运行；缺文件、重复键、非法引用或计数资源损坏均启动失败，绝不自动降级。

真实接入按 [F4 配置示例](docs/features/F4/design.md#32-provider-协议与模型配置) 将主侧绑定 DeepSeekProvider/Chat、备侧绑定 OpenAICompatibleProvider/Responses，当前 model_id=deepseek-flash；api_protocol 与 structured_output_mode 显式必填，修改 YAML 后重启。真实凭据由维护者从 [credentials.example.yaml](config/credentials.example.yaml) 复制到同目录 credentials.yaml 后本地填写，不进入 `.env`、环境变量或版本管理。仅配置 Mock 时不读取凭据文件。

F5 起每个模型还必须显式声明严格布尔 `supports_streaming`；当前默认两条 Mock 为 true。参考历史F4配置切真实时保留这个新字段，不整体替换成缺少字段的旧YAML；false仍可普通调用/探测，但流式调用前拒绝。能力声明不替代实际接入验证。

导入 `main` 不创建应用；Uvicorn 通过 `--factory` 调用 `create_app`。客户端在应用 lifespan 构造/释放，每 Provider 配置一个可复用实例。两种真实客户端不继承环境代理，不跟随重定向，重试关闭。自动化测试显式注入配置或使用临时运行目录中的同名 `.env`，不依赖或修改开发者配置，不使用 `.env.test`。

### Agent 凭据与本地拨款

先迁移到 `f9_001` 并重启 Gateway。在另一个终端进入本项目目录，首次为测试 Agent 创建身份并签发凭据。以下命令将完整凭据保存在当前 shell 变量中。旧版请求没有可信 Agent 归属，仅供本机管理员核查。

```bash
export PYTHONPATH=src
uv run python -m admin create-agent orders 售后客服
GATEWAY_AGENT_TOKEN=$(uv run python -m admin issue orders)
uv run python -m admin deposit orders 1.00 --operation-id orders-initial-001
```

每次新的拨款使用新的操作编号，重复同一编号和内容不会重复入账。所有 `/v1/` 请求携带上述 Bearer 凭据。`GET /healthz` 是公开存活探针。两条默认 Mock 占用零元，带凭据即可使用。真实调用按 [prices.yaml](config/prices.yaml) 中显式绑定的账户、模型、生效版本计价。价格与节假日日历由维护者更新后重启加载；已保存的价格快照供历史查询。

```bash
curl -sS -D - -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" \
  -H 'Content-Type: application/json' http://127.0.0.1:8000/v1/llm \
  -d '{"model":"general-primary","prompt":{"name":"basic_text","version":"1.0.0"},"messages":[{"role":"user","content":"查询订单 A123"}]}'
curl -sS -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" http://127.0.0.1:8000/v1/billing/summary
curl -sS -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" 'http://127.0.0.1:8000/v1/billing/requests?limit=10'
# REQUEST_ID 取自普通响应的 X-Request-ID 或创建流返回的 data.request_id
curl -sS -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" "http://127.0.0.1:8000/v1/billing/requests/${REQUEST_ID}"
```

本机管理员通过 `python -m admin --help` 查看命令。轮换用 `rotate orders PUBLIC_ID`，撤销用 `revoke orders PUBLIC_ID`，其中 PUBLIC_ID 是凭据第一个点之前的公开标识。凭据轮换后继续使用原账户余额。本期不自动迁移开发库或创建默认管理员凭据。

向 `POST http://127.0.0.1:8000/v1/llm` 发送：

```json
{
  "model": "general-primary",
  "prompt": {"name": "basic_text", "version": "1.0.0"},
  "messages": [{"role": "user", "content": "请解释什么是 TTFT"}]
}
```

F2 还可选择 `context_answer@1.0.0` 或 `context_answer@1.1.0`：

```json
{
  "model": "general-primary",
  "prompt": {
    "name": "context_answer",
    "version": "1.1.0",
    "variables": {"context": "订单 A123 的商品为充电器。"}
  },
  "messages": [{"role": "user", "content": "订单 A123 的商品是什么？"}]
}
```

运行时变量只进入末条 User，System 固定；调用方不能覆盖保留变量 `message` 或提交示例。context 必填、非空白、最多 10,000 字符，最终 User（含标签/换行）最多 20,000 字符，超限直接拒绝。1.1.0 比 1.0.0 多两个静态示例，最终 6 条消息仍只调用 Provider 一次。模板和版本精确选择，不自动回退；缺变量、额外变量与总长错误均在模型调用前拒绝。

完整 System、静态示例、User 与模型消息边界一起计 Token。本地固定资源预检要求：输入计数 + 输出预算 + 1,024 余量 ≤ 窗口。默认输出预算 1,024，平台上限 4,096；请求可传正整数 `max_output_tokens`。默认总调用超时 30 秒、上限 120 秒，可传 `timeout_seconds`；显式 null/布尔/字符串/小数拒绝。固定非思考，超预算不裁剪、不调小、不重试。

Trace 保存最终消息指纹、模型元信息、生效预算、计数资源版本和实际 Usage，指纹仍只标识消息内容；本地计数不冒充云端 Usage。资源来源/摘要见 [manifest](assets/tokenizers/deepseek-v4.1-flash/manifest.json)。

默认 Mock 返回 `MOCK_REPLY`，普通响应和流式终态均报告固定模拟用量（输入 10、输出 1、合计 11）。Trace 的 Attempt 通过 `adapter=mock` 标识来源。上游缺失用量时，普通成功正文示例为 `{"success":true,"code":"ok","data":{"text":"回答正文","usage":null},"message":"成功"}`；data 只含 text/usage，model、actual_model、attempts 仅内部保留。错误为稳定 HTTP/code、data=null；length 为 output_truncated，F3 不续写或恢复。

普通调用和主动探测从 `X-Request-ID` 响应头取得 ID，创建流还可从 `data.request_id` 取得。只在本机或隔离开发网络使用诊断接口。将下面的 UUID 替换成刚获得的 ID：

```bash
curl -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" -sS http://127.0.0.1:8000/v1/traces/00000000-0000-0000-0000-000000000000
```

先看 `data.status` 和 `error_stage`，再按 `attempt_no` 查看每次尝试的模型、结果和原因。备用模型成功时，主模型失败仍在列表中。每次实际回报的用量汇入 `data.usage.known_subtotal`，`unknown_attempts` 列出缺少用量的尝试编号。历史缺失的观测值为 null。查询读取 PostgreSQL 已提交状态，重复查询 pending 请求不会启动生成。字段与时间口径见[诊断契约](docs/contracts.md#f8-按请求查询诊断信息)。

流式调用先创建，再订阅；默认 Mock 可直接运行：

```bash
curl -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" -i -X POST http://127.0.0.1:8000/v1/llm/stream \
  -H 'Content-Type: application/json' \
  -d '{"model":"general-primary","prompt":{"name":"basic_text","version":"1.0.0"},"messages":[{"role":"user","content":"请解释 TTFT"}],"max_output_tokens":128,"timeout_seconds":30}'
```

创建成功为202，data为`{"request_id":"...","status":"pending"}`，此时不调用模型。把返回ID填入下面URL；首次有效GET启动生成：

```bash
curl -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" -N http://127.0.0.1:8000/v1/llm/stream/替换为request_id/events
# 中断后，假设最后成功处理的 SSE id 为12；省略after_seq则从0回放
curl -H "Authorization: Bearer ${GATEWAY_AGENT_TOKEN}" -N 'http://127.0.0.1:8000/v1/llm/stream/替换为request_id/events?after_seq=12'
```

业务事件为response.delta/completed/failed/canceling/canceled，`id`是连续数据库seq；15秒空闲response.heartbeat无id、不落库。调用方按最后成功处理的id续传并去重；允许重投，不承诺端到端恰好一次。同一请求可多订阅，断连不停止生成；生成/取消所有者按数据库提交唯一终态。完成已提交后，订阅失败不能覆盖completed。主动取消使用前述POST取消及轮询接口，取消前已提交内容仍可回放。

创建/订阅HTTP202/200、心跳、连接结束都不能判模型成功；终态为completed/failed/canceled，canceling仍在处理中；取消调用方可只轮询取消接口确认终态。终态且游标已读完为204，超当前最大游标400，非法游标422，找不到有效流式请求404。completed只含request_id/usage（未知null），不重复完整回答。流式不接受stream/response_schema额外字段。

生成总期限从首次有效GET认领前的B开始，包含认领、Provider和保存，重连不重置。订阅无整体期限，单次发送最多30秒；PG空结果等待100ms，单页最多100条，查询释放连接后再发送。普通调用与探测保持原协议。

TTFT是B至活跃订阅首次成功发送文本的时间（空格/换行也计入），只补记一次；历史或重启回放不重算。Generation是上游首段文本到达至明确远端终态到达。未知null，保存于内部Trace/持久化诊断，不公开到业务帧，不以总耗时减TTFT冒充模型纯生成时间。

`GET /healthz` 只检查服务存活；`POST /v1/models/general-primary/health` 或备用逻辑名发起主动探测，不带请求体，固定 16 Token/10 秒。成功 data 只含 latency_ms，实报 Usage 可通过 provider_probe 的 Trace 查看，探测正文不落库；Mock 探测不是远端连通证明。

```bash
uv run python -m pytest -q
uv run python -m pytest tests/unit tests/integration -q
uv run python -m pytest tests/protocol -q
uv run python -m pytest tests/smoke/test_http_server.py -q
uv run python -m pytest tests/smoke/test_f5_http_server.py -q
```

默认测试不访问真实 Provider；持久化相关测试需要 Docker，并自动启动自有 PostgreSQL（临时密码、随机回环端口、独立库/卷），不读取或清空开发数据库。允许协议替身使用回环地址，阻止读取实际凭据和外部连接；单 worker 进程冒烟会清理进程。真实测试必须由维护者填好本地凭据后显式执行 `uv run python -m pytest tests/live --run-live -x -q`；缺前置条件是失败，不静默跳过。F4 扩展为主、备各文本/结构化/主动探测共六例，未完成所有必验与独立审查不称验收通过。默认Mock仍返回MOCK_REPLY，不会自动生成任意Schema数据；结构化成功使用显式脚本Mock或真实接入验证。当前受控 Prompt 与完整历史回归证据见 [F2 测试方案](docs/features/F2/test-plan.md)；配置工厂与原 F1 的历史证据分别见 [F1-O1](docs/features/F1/optimizations/O1/test-plan.md) 和 [F1](docs/features/F1/test-plan.md)。

F5另加主/备各一次真实流式，共8个live用例；仅执行本项两例使用 `uv run python -m pytest tests/live/test_f5_streaming.py --run-live -x -q`。本项实际回执与普通6例历史证据分开，不因增加新测试就重复全部真实调用。

F5-O1 的新增验收使用 `uv run python -m pytest tests/live/test_f5o1_acceptance.py --run-live -x -q -o junit_family=xunit1`，主/备各文本、结构化、流式一次，共六次有成本调用，数据库仍为临时测试库。默认测试不执行这些调用；维护者切真实配置时只修改 providers/models，保留 database 和 supports_streaming 等必需字段。

## F7 有限恢复（已验收）

[设计](docs/features/F7/design.md)与[52组测试方案](docs/features/F7/test-plan.md)已确认；[实施步骤](docs/features/F7/implementation-plan.md)和[代码导读](docs/features/F7/implementation-summary.md)记录实现与验收。R2独审APPROVED；最新最终完整全量开启--run-live，1776项全部通过，含16个真实调用，0跳过/0未选中，原297项也已完整重跑；详见测试方案3.9与[真实全量证据](docs/features/F7/evidence-all-live.json)。F7 对应迁移 f7_001。F8 迁移为 f8_001，F9 当前 head 为 f9_001；启动前在项目根执行 `uv run alembic upgrade head`。

调用方可选initial_output_tokens指定首次预算，max_output_tokens仍是每次生成的授权上限。入口按完整max预留窗口；明确截断且尚未提交流式内容时，可同模型直接增到max重答。结构化格式错误最多一次受控修复。网络恢复、增长与修复共用整个请求最多3次、每候选最多2次；候选固定且能力/完整预算必须满足。

timeout_seconds覆盖整个请求，重试不重置；单次上限为min(模型max_timeout_seconds, 请求剩余时间)，无统一10秒。首次非空delta成功提交PG后禁止恢复，空格/换行也算；取消接受后不再启动模型。恢复期间订阅仍按原规则发送15秒空闲心跳。

配置示例见[完整安全示例](config/gateway.example.yaml)，按需合并recovery与fallback_models；当前实际gateway.yaml未改，仍两条Mock。Provider协议由配置决定，调用方不传协议/重试策略。成功只返回原text/usage/(parsed)，usage汇总各Attempt，任一次未知则整体null；内部保存已知部分，费用可通过独立账务接口核对。health探测固定单次原模型，healthz不调用模型。

## 递增路线

| 功能 | 交付边界 |
| --- | --- |
| F0 文档先行 | 架构、契约、验收矩阵和进度记录；用户已同意进入 F1 范围讨论 |
| F1 统一入口与普通调用 | 一个固定 System 模板、稳定逻辑模型 `general-primary` 和 MockProvider 构成本地最小普通调用；入口错误零上游调用，建立最小 Trace；真实模型留待 F3 |
| F2 受控 Prompt | 在 F1 固定模板基础上完善模板名称/版本管理、变量装配与边界 |
| F3 模型配置与适配器 | 已实现；[设计/测试证据](docs/features/F3/test-plan.md)：统一三种适配器、YAML/凭据、预算与探测；离线570通过、Claude Code第1轮无P0–P2；真实接入四例与第2轮APPROVED，验收通过 |
| F4 Structured Output | [已验收](docs/features/F4/test-plan.md)：Schema预检、Chat/Responses约束生成、完整预算、精确十进制与严格结果验收；代码导读已同步 |
| F5 Streaming | [已验收](docs/features/F5/test-plan.md#310-最终验收与第2轮审查处置)：真增量 SSE、心跳/总期限、统一事件、背压/断连清理及最小指标 |
| F5-O1 统一持久化基础 | [已验收](docs/features/F5/optimizations/O1/test-plan.md)：PostgreSQL/Compose、迁移、普通与流式 Request/Attempt、流式事件先存后发及重启收口；不改变 POST 直接 SSE 形式 |
| F5-O2 两阶段调用与断点续传 | [已验收](docs/features/F5/optimizations/O2/test-plan.md#39-最终验收)：POST /v1/llm/stream 返回 202/ID，首次 GET /v1/llm/stream/{request_id}/events 启动；按可选 after_seq 补读，多订阅、断连继续生成；心跳不保存 |
| F6 流式取消 | [设计](docs/features/F6/design.md)已确认、[测试方案](docs/features/F6/test-plan.md)已确认，已验收通过；pending/running均经canceling，POST取消及轮询至终态，完成/取消按数据库先提交者生效 |
| F7 重试与 fallback | 已验收：有限预算、错误分类、能力匹配及提交边界；见[F7](docs/features/F7/design.md) |
| F8 Trace 完整性与诊断查询 | 基础持久化前移到 F5-O1；在 PostgreSQL 上补齐探测、取消、重试等路径和诊断查询，为用量核算提供可追溯依据 |
| [F9 用量与计费](docs/features/F9/design.md)（验收通过） | 价格配置与版本、实际用量分类、费用计算、账单持久化与对账；区分本地预估与实际 Usage，未知用量不得按零结算。Agent 手动拨款、按尝试预留与结算、消耗总览及请求明细 |
| [F10 总验收](docs/features/F10/design.md)（验收通过，全量2039及独立审查APPROVED） | 调用方使用闭环、故障及账务一致性、并发与持续运行基线、历史全量和真实接入 |

本阶段已按“F5-O1 持久化基础 → F5-O2 两阶段调用与续传 → F6 主动取消 → F7 重试与 fallback → F8 Trace 完整性 → F9 用量与计费 → F10 总验收”完成交付。计费按每次实际Provider尝试留痕，覆盖失败、取消及重试可能产生的用量，供应商成本与Agent扣款分别记录；缓存等分类按配置价格计算，本地Token计数用于预检与预估。正式供应商账单对账仍未验证。后续1.7设计与测试另行确认，遗留及证据边界见[收尾记录](docs/1.6-closeout.md)。

每个功能先确认设计，再单独确认本项测试方案，随后按 Red → Green → Refactor 推进。Mock、FastAPI 接口测试和真实 Provider 冒烟测试分开记录，不能互相替代。跨功能标准见 [测试原则](docs/test-plan.md)，当前状态见 [进度记录](docs/progress.md)。

F1 的最小范围见 [F1 设计方案](docs/features/F1/design.md)，逐例验收见 [F1 测试方案](docs/features/F1/test-plan.md)；后续功能按 [文档约定](docs/AGENTS.md) 分别维护设计与测试方案。F1 先用单一静态模板和模型白名单兑现“Prompt 必选、未知模型不调用 Provider”的入口契约；F2/F3 再扩展完整能力，不把 F1 的最小能力称为已完成 F2/F3。

## 当前代码结构

下面仅列当前实际源码。F1–F5 的组件之外，F5-O1 增加 persistence 数据库/表结构/事务存储组件；项目根的 compose.yaml 管理 PostgreSQL，alembic.ini 与 migrations/ 管理显式迁移。O2增加生成任务所有者和只读订阅组件；F6在现有管理器/执行器内实现主动取消和首次Provider启动协调，当前验收通过。

```text
src/
├── main.py
├── admin.py
├── api/
│   ├── routes.py
│   ├── billing.py
│   ├── identity.py
│   ├── dependencies.py
│   ├── sse.py
│   └── errors.py
├── contracts.py
├── trace_contracts.py
├── errors.py
├── constants.py
├── settings.py
├── utils/
│   ├── __init__.py
│   ├── diagnostic_values.py
│   └── json_codec.py
├── middleware/
│   └── request_context.py
├── services/
│   ├── gateway.py
│   ├── recovery.py
│   ├── prices.py
│   ├── streaming.py
│   ├── streaming_manager.py
│   ├── subscriptions.py
│   ├── validation.py
│   ├── prompts.py
│   ├── models.py
│   ├── credentials.py
│   ├── token_counters/
│   │   ├── __init__.py
│   │   ├── base.py
│   │   └── deepseek_v41.py
│   ├── token_budget.py
│   └── trace.py
├── persistence/
│   ├── __init__.py
│   ├── database.py
│   ├── billing.py
│   ├── tables.py
│   ├── billing_query.py
│   ├── trace_query.py
│   └── store.py
└── providers/
    ├── base.py
    ├── mock.py
    ├── deepseek.py
    ├── openai_compatible.py
    ├── streaming.py
    └── factory.py
```

源码直接位于 `src/`，通过 `--app-dir src` 加载；测试沿用 `pyproject.toml` 的 `pythonpath = ["src"]`。

`main.py` 只组装应用；`settings.py` 加载配置；`middleware/` 处理请求上下文与响应完成边界；`api/` 处理传输，`services/` 集中内部组件与调用编排，`providers/` 隔离实现与构造；`api/dependencies.py` 提供替换为 MockProvider 的注入边界。目录中的组件按职责命名，不要求每个模块都创建一个 `XxxService` 类。

项目工作流见 [AGENTS.md](AGENTS.md)，文档目录与维护约束见 [docs/AGENTS.md](docs/AGENTS.md)。

[F3代码实现导读](docs/features/F3/implementation-summary.md)提供文件/类/函数阅读顺序；[F3-O1](docs/features/F3/optimizations/O1/implementation-summary.md)解释职责拆分和策略选择，本项离线606通过/真实4通过，Claude Code第1轮APPROVED，已验收。每个模型必须显式声明token_counter，未知策略或不兼容绑定在客户端创建前拒绝。TokenBudget按模型配置选择计数策略，ProviderClients管理自有连接；通用入口不判断具体型号。

[F4代码实现导读](docs/features/F4/implementation-summary.md)按真实文件/函数说明Schema预检、固定Prompt、完整约束计数、两种协议与精确数值链路；独立验收状态以本项测试方案为准。
